#!/usr/bin/env python3
"""
Webhook Server Example
Example implementation of a webhook server for receiving Jenkins notifications
"""

import asyncio
import json
import hmac
import hashlib
from fastapi import FastAPI, Request, HTTPException, Header
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

from src.utils.config_loader import ConfigLoader
from src.core.decision_engine import DecisionEngine
from src.integrations.jenkins_client import JenkinsBuild
from datetime import datetime
from loguru import logger


app = FastAPI(title="AI DevOps Webhook Server")

# Global components
config = None
decision_engine = None


class JenkinsWebhookPayload(BaseModel):
    """Jenkins webhook payload model"""
    name: str
    url: str
    build: dict


class GitLabWebhookPayload(BaseModel):
    """GitLab webhook payload model"""
    object_kind: str
    object_attributes: dict
    project: dict


def initialize_components():
    """Initialize framework components"""
    global config, decision_engine
    
    try:
        config = ConfigLoader()
        decision_engine = DecisionEngine(config.config)
        logger.info("Framework components initialized")
    except Exception as e:
        logger.error(f"Failed to initialize components: {e}")
        raise


def verify_signature(payload: bytes, signature: str, secret: str) -> bool:
    """Verify webhook signature"""
    if not secret:
        return True  # Skip verification if no secret configured
    
    expected_signature = hmac.new(
        secret.encode(),
        payload,
        hashlib.sha256
    ).hexdigest()
    
    return hmac.compare_digest(f"sha256={expected_signature}", signature)


@app.on_event("startup")
async def startup_event():
    """Initialize on server startup"""
    initialize_components()


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "components": {
            "config": config is not None,
            "decision_engine": decision_engine is not None
        }
    }


@app.post("/webhook/jenkins")
async def jenkins_webhook(
    payload: JenkinsWebhookPayload,
    request: Request,
    x_hub_signature: Optional[str] = Header(None),
    x_jenkins_event: Optional[str] = Header(None)
):
    """Handle Jenkins webhook notifications"""
    
    try:
        logger.info(f"Received Jenkins webhook: {payload.name} - {payload.build.get('status', 'unknown')}")
        
        # Verify signature if secret is configured
        webhook_secret = config.get('jenkins.webhook_secret') if config else None
        if webhook_secret:
            body = await request.body()
            if not verify_signature(body, x_hub_signature or "", webhook_secret):
                raise HTTPException(status_code=401, detail="Invalid signature")
        
        # Process only completed builds
        build_phase = payload.build.get('phase')
        build_status = payload.build.get('status')
        
        if build_phase == 'FINISHED' and build_status in ['FAILURE', 'UNSTABLE', 'ABORTED']:
            # Extract build information
            build_number = payload.build.get('number')
            job_name = payload.name
            
            logger.info(f"Processing failed build: {job_name}#{build_number}")
            
            # Get detailed build information
            if decision_engine and decision_engine.jenkins_client:
                build_details = decision_engine.jenkins_client.get_build_details(
                    job_name, build_number
                )
                
                if build_details:
                    # Process the failure
                    result = await decision_engine.process_failure(build_details)
                    
                    return JSONResponse({
                        "received": True,
                        "job": job_name,
                        "build": build_number,
                        "status": "processed",
                        "action_taken": result.action_taken.value,
                        "success": result.success
                    })
                else:
                    logger.warning(f"Could not fetch build details for {job_name}#{build_number}")
            else:
                logger.error("Decision engine or Jenkins client not initialized")
        
        return JSONResponse({
            "received": True,
            "job": payload.name,
            "build": payload.build.get('number'),
            "status": "ignored",
            "reason": "Not a failure or already processed"
        })
        
    except Exception as e:
        logger.error(f"Error processing Jenkins webhook: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/webhook/gitlab")
async def gitlab_webhook(
    payload: GitLabWebhookPayload,
    x_gitlab_token: Optional[str] = Header(None)
):
    """Handle GitLab webhook notifications"""
    
    try:
        logger.info(f"Received GitLab webhook: {payload.object_kind}")
        
        # Verify token if configured
        webhook_token = config.get('gitlab.webhook_token') if config else None
        if webhook_token and x_gitlab_token != webhook_token:
            raise HTTPException(status_code=401, detail="Invalid token")
        
        # Process merge request events
        if payload.object_kind == 'merge_request':
            mr_action = payload.object_attributes.get('action')
            mr_state = payload.object_attributes.get('state')
            mr_iid = payload.object_attributes.get('iid')
            project_id = payload.project.get('path_with_namespace')
            
            logger.info(f"MR {mr_iid} in {project_id}: {mr_action} - {mr_state}")
            
            # Handle MR merge to learn from success
            if mr_action == 'merge' and decision_engine:
                await _handle_mr_merge(project_id, mr_iid)
            
            # Handle MR feedback
            elif mr_action in ['approved', 'closed']:
                await _handle_mr_feedback(project_id, mr_iid, mr_action)
        
        return JSONResponse({
            "received": True,
            "event": payload.object_kind,
            "status": "processed"
        })
        
    except Exception as e:
        logger.error(f"Error processing GitLab webhook: {e}")
        raise HTTPException(status_code=500, detail=str(e))


async def _handle_mr_merge(project_id: str, mr_iid: int):
    """Handle merge request merge to learn from success"""
    
    try:
        if decision_engine and decision_engine.gitlab_client:
            # Get MR details
            mr_status = decision_engine.gitlab_client.get_pr_status(project_id, mr_iid)
            
            if mr_status and mr_status.get('approved'):
                logger.info(f"AI-generated MR {mr_iid} was merged successfully")
                
                # This would update the RAG system with successful outcome
                # Implementation depends on how you track MR to pattern mapping
                
    except Exception as e:
        logger.error(f"Error handling MR merge: {e}")


async def _handle_mr_feedback(project_id: str, mr_iid: int, action: str):
    """Handle merge request feedback for learning"""
    
    try:
        logger.info(f"MR {mr_iid} in {project_id} was {action}")
        
        # This would update the RAG system with feedback
        # Implementation depends on your feedback tracking system
        
    except Exception as e:
        logger.error(f"Error handling MR feedback: {e}")


@app.post("/api/v1/analyze")
async def analyze_failure(request: dict):
    """Manual failure analysis endpoint"""
    
    try:
        job_name = request.get('job_name')
        build_number = request.get('build_number')
        project_id = request.get('project_id')
        
        if not job_name or not build_number:
            raise HTTPException(status_code=400, detail="job_name and build_number required")
        
        if not decision_engine:
            raise HTTPException(status_code=503, detail="Decision engine not initialized")
        
        # Get build details
        build_details = decision_engine.jenkins_client.get_build_details(
            job_name, build_number
        )
        
        if not build_details:
            raise HTTPException(status_code=404, detail="Build not found")
        
        # Process failure
        result = await decision_engine.process_failure(build_details, project_id)
        
        return {
            "success": True,
            "action_taken": result.action_taken.value,
            "confidence": result.metadata.get('base_confidence', 0) if result.metadata else 0,
            "execution_time": result.execution_time,
            "pr_url": result.pr_url,
            "build_retriggered": result.build_retriggered,
            "result_details": result.result_details
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in manual analysis: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/v1/statistics")
async def get_statistics():
    """Get framework statistics"""
    
    try:
        if not decision_engine:
            raise HTTPException(status_code=503, detail="Decision engine not initialized")
        
        stats = decision_engine.get_statistics()
        return stats
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting statistics: {e}")
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    
    # Run server
    uvicorn.run(
        "webhook_server:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )