#!/usr/bin/env python3
"""
Initialize Vector Database
Script to initialize and populate the vector database with initial data
"""

import sys
import json
from pathlib import Path
from datetime import datetime
from loguru import logger

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from src.utils.config_loader import ConfigLoader
from src.ai.rag_system import RAGSystem, FailurePattern


def create_sample_patterns() -> list[FailurePattern]:
    """Create sample failure patterns for initialization"""
    
    patterns = [
        FailurePattern(
            id="",
            job_name="build-pipeline",
            failure_type="compilation",
            error_signature="Failed to compile: package not found",
            root_cause="Missing dependency in package.json",
            solution_applied="Update package.json with missing dependency",
            success_rate=0.85,
            occurrence_count=5,
            last_seen=datetime.now(),
            metadata={
                "severity": "medium",
                "affected_components": ["build", "npm"],
                "file_patterns": ["package.json", "yarn.lock"]
            }
        ),
        FailurePattern(
            id="",
            job_name="test-suite",
            failure_type="test_failure",
            error_signature="Test timeout: exceeded 30000ms",
            root_cause="Test taking too long due to network latency",
            solution_applied="Increase test timeout and add retry logic",
            success_rate=0.92,
            occurrence_count=3,
            last_seen=datetime.now(),
            metadata={
                "severity": "low",
                "affected_components": ["tests", "network"],
                "file_patterns": ["*.test.js", "jest.config.js"]
            }
        ),
        FailurePattern(
            id="",
            job_name="deploy-staging",
            failure_type="configuration_error",
            error_signature="Environment variable not set: DATABASE_URL",
            root_cause="Missing environment variable in deployment configuration",
            solution_applied="Add DATABASE_URL to environment variables",
            success_rate=0.95,
            occurrence_count=8,
            last_seen=datetime.now(),
            metadata={
                "severity": "high",
                "affected_components": ["deployment", "environment"],
                "file_patterns": [".env", "docker-compose.yml"]
            }
        ),
        FailurePattern(
            id="",
            job_name="security-scan",
            failure_type="security_issue",
            error_signature="Vulnerability found: package xyz version 1.2.3",
            root_cause="Outdated dependency with known security vulnerability",
            solution_applied="Update package to latest secure version",
            success_rate=0.88,
            occurrence_count=2,
            last_seen=datetime.now(),
            metadata={
                "severity": "critical",
                "affected_components": ["security", "dependencies"],
                "file_patterns": ["package.json", "requirements.txt"]
            }
        ),
        FailurePattern(
            id="",
            job_name="integration-tests",
            failure_type="infrastructure_issue",
            error_signature="Connection refused: database not available",
            root_cause="Test database service not running",
            solution_applied="Ensure database service is started before tests",
            success_rate=0.78,
            occurrence_count=4,
            last_seen=datetime.now(),
            metadata={
                "severity": "medium",
                "affected_components": ["infrastructure", "database"],
                "file_patterns": ["docker-compose.test.yml"]
            }
        )
    ]
    
    return patterns


def main():
    """Main initialization function"""
    
    logger.info("Initializing vector database...")
    
    try:
        # Load configuration
        config = ConfigLoader()
        config.create_directories()
        
        # Initialize RAG system
        rag_system = RAGSystem(config.config)
        
        # Create and add sample patterns
        sample_patterns = create_sample_patterns()
        
        logger.info(f"Adding {len(sample_patterns)} sample patterns...")
        
        for pattern in sample_patterns:
            success = rag_system.add_failure_pattern(pattern)
            if success:
                logger.info(f"Added pattern: {pattern.failure_type} - {pattern.root_cause}")
            else:
                logger.error(f"Failed to add pattern: {pattern.failure_type}")
        
        # Get statistics
        stats = rag_system.get_statistics()
        
        logger.info("Vector database initialization completed!")
        logger.info(f"Total patterns: {stats['total_patterns']}")
        logger.info(f"Pattern distribution: {stats['pattern_distribution']}")
        
        # Save statistics
        stats_file = Path(config.get('paths.data', './data')) / 'init_stats.json'
        with open(stats_file, 'w') as f:
            json.dump(stats, f, indent=2, default=str)
        
        logger.info(f"Statistics saved to: {stats_file}")
        
        print("\n✅ Vector database initialized successfully!")
        print(f"📊 Total patterns: {stats['total_patterns']}")
        print(f"📁 Database path: {config.get('vector_db.path')}")
        print(f"📈 Statistics saved to: {stats_file}")
        
    except Exception as e:
        logger.error(f"Initialization failed: {e}")
        print(f"\n❌ Initialization failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()