"""
AI DevOps Framework Dashboard
Real-time monitoring and visualization of Jenkins failure analysis and AI resolutions
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import asyncio
import json
import sys
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Any
import time

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from src.utils.config_loader import ConfigLoader
from src.core.decision_engine import DecisionEngine
from src.integrations.jenkins_client import JenkinsClient
from src.integrations.gitlab_client import GitLabClient


class Dashboard:
    def __init__(self):
        """Initialize the dashboard"""
        
        # Page configuration
        st.set_page_config(
            page_title="AI DevOps Dashboard",
            page_icon="🤖",
            layout="wide",
            initial_sidebar_state="expanded"
        )
        
        # Initialize session state
        if 'framework' not in st.session_state:
            st.session_state.framework = None
        if 'last_refresh' not in st.session_state:
            st.session_state.last_refresh = None
        if 'auto_refresh' not in st.session_state:
            st.session_state.auto_refresh = True
        
        # Custom CSS
        self._apply_custom_css()
    
    def _apply_custom_css(self):
        """Apply custom CSS styling"""
        
        st.markdown("""
        <style>
        .main-header {
            font-size: 2.5rem;
            font-weight: bold;
            color: #1f77b4;
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .metric-card {
            background-color: #f0f2f6;
            padding: 1rem;
            border-radius: 0.5rem;
            border-left: 4px solid #1f77b4;
        }
        
        .success-metric {
            border-left-color: #2ca02c;
        }
        
        .warning-metric {
            border-left-color: #ff7f0e;
        }
        
        .error-metric {
            border-left-color: #d62728;
        }
        
        .status-indicator {
            display: inline-block;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-right: 8px;
        }
        
        .status-success {
            background-color: #2ca02c;
        }
        
        .status-warning {
            background-color: #ff7f0e;
        }
        
        .status-error {
            background-color: #d62728;
        }
        
        .scrollable-container {
            max-height: 400px;
            overflow-y: auto;
        }
        </style>
        """, unsafe_allow_html=True)
    
    def initialize_framework(self):
        """Initialize the framework if not already done"""
        
        if st.session_state.framework is None:
            try:
                config = ConfigLoader()
                st.session_state.framework = DecisionEngine(config.config)
                st.session_state.jenkins_client = JenkinsClient(config.config)
                st.session_state.gitlab_client = GitLabClient(config.config)
                st.success("✅ Framework initialized successfully!")
            except Exception as e:
                st.error(f"❌ Failed to initialize framework: {e}")
                return False
        return True
    
    def render_header(self):
        """Render the dashboard header"""
        
        st.markdown('<h1 class="main-header">🤖 AI DevOps Jenkins Dashboard</h1>', unsafe_allow_html=True)
        
        # Auto-refresh controls
        col1, col2, col3 = st.columns([1, 1, 2])
        
        with col1:
            if st.button("🔄 Refresh Now", type="primary"):
                st.session_state.last_refresh = None
                st.rerun()
        
        with col2:
            st.session_state.auto_refresh = st.checkbox("🔄 Auto Refresh", value=st.session_state.auto_refresh)
        
        with col3:
            if st.session_state.last_refresh:
                st.info(f"Last refreshed: {st.session_state.last_refresh.strftime('%H:%M:%S')}")
    
    def render_sidebar(self):
        """Render the sidebar with controls and information"""
        
        with st.sidebar:
            st.header("⚙️ Controls")
            
            # Refresh interval
            refresh_interval = st.slider("Refresh Interval (seconds)", 5, 60, 10)
            
            # Connection status
            st.subheader("🔌 Connection Status")
            
            if self.initialize_framework():
                # Test connections
                jenkins_status = "🟢 Connected" if st.session_state.jenkins_client.test_connection() else "🔴 Disconnected"
                gitlab_status = "🟢 Connected" if st.session_state.gitlab_client.test_connection() else "🔴 Disconnected"
                
                st.metric("Jenkins", jenkins_status)
                st.metric("GitLab", gitlab_status)
            
            st.divider()
            
            # Quick actions
            st.subheader("🚀 Quick Actions")
            
            if st.button("📊 View Statistics"):
                st.session_state.show_stats = True
            
            if st.button("🔍 Analyze Job"):
                st.session_state.show_analyze = True
            
            if st.button("📈 Export Data"):
                st.session_state.export_data = True
    
    def render_overview_metrics(self):
        """Render overview metrics"""
        
        st.header("📊 Overview")
        
        if not self.initialize_framework():
            return
        
        # Get statistics
        stats = st.session_state.framework.get_statistics()
        rag_stats = stats.get('rag_statistics', {})
        
        # Create metric columns
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric(
                "Total Actions",
                stats.get('total_actions', 0),
                delta=None
            )
        
        with col2:
            success_rate = stats.get('success_rate', 0)
            st.metric(
                "Success Rate",
                f"{success_rate:.1%}",
                delta=f"{success_rate:.1%}"
            )
        
        with col3:
            st.metric(
                "Failure Patterns",
                rag_stats.get('total_patterns', 0)
            )
        
        with col4:
            st.metric(
                "Resolutions",
                rag_stats.get('total_resolutions', 0)
            )
        
        # Action distribution chart
        if stats.get('action_distribution'):
            st.subheader("Action Distribution")
            
            action_data = stats['action_distribution']
            fig = px.pie(
                values=list(action_data.values()),
                names=list(action_data.keys()),
                title="Actions Taken by AI"
            )
            st.plotly_chart(fig, use_container_width=True)
    
    def render_recent_activity(self):
        """Render recent activity feed"""
        
        st.header("🕐 Recent Activity")
        
        if not self.initialize_framework():
            return
        
        # Get recent failed jobs
        try:
            failed_jobs = st.session_state.jenkins_client.get_failed_jobs(since_hours=24)
            
            if failed_jobs:
                # Create DataFrame
                job_data = []
                for job in failed_jobs[:10]:  # Show last 10
                    job_data.append({
                        'Job': job.name,
                        'Build': f"#{job.build_number}",
                        'Status': job.status,
                        'Time': job.timestamp.strftime('%H:%M:%S'),
                        'Duration': f"{job.duration / 1000:.1f}s"
                    })
                
                df = pd.DataFrame(job_data)
                
                # Color code status
                def color_status(val):
                    if val == 'FAILURE':
                        return 'background-color: #ffebee'
                    elif val == 'UNSTABLE':
                        return 'background-color: #fff3e0'
                    else:
                        return 'background-color: #e8f5e8'
                
                styled_df = df.style.applymap(color_status, subset=['Status'])
                st.dataframe(styled_df, use_container_width=True)
            else:
                st.info("✅ No failed jobs in the last 24 hours")
        
        except Exception as e:
            st.error(f"Error fetching recent activity: {e}")
    
    def render_pattern_analysis(self):
        """Render failure pattern analysis"""
        
        st.header("🧠 Pattern Analysis")
        
        if not self.initialize_framework():
            return
        
        try:
            rag_stats = st.session_state.framework.rag_system.get_statistics()
            
            # Pattern distribution
            if rag_stats.get('pattern_distribution'):
                st.subheader("Failure Types Distribution")
                
                pattern_data = rag_stats['pattern_distribution']
                fig = px.bar(
                    x=list(pattern_data.keys()),
                    y=list(pattern_data.values()),
                    title="Failure Patterns by Type"
                )
                fig.update_xaxes(tickangle=45)
                st.plotly_chart(fig, use_container_width=True)
            
            # Success rate over time (placeholder)
            st.subheader("Learning Progress")
            
            # Create sample data for demonstration
            dates = pd.date_range(end=datetime.now(), periods=30, freq='D')
            success_rates = [0.6 + (i * 0.01) + (0.1 * (i % 3)) for i in range(30)]
            
            fig = px.line(
                x=dates,
                y=success_rates,
                title="AI Success Rate Over Time",
                labels={'x': 'Date', 'y': 'Success Rate'}
            )
            fig.update_yaxes(tickformat='.1%')
            st.plotly_chart(fig, use_container_width=True)
        
        except Exception as e:
            st.error(f"Error in pattern analysis: {e}")
    
    def render_active_prs(self):
        """Render active pull requests"""
        
        st.header("🔀 Active Pull Requests")
        
        if not self.initialize_framework():
            return
        
        st.info("📝 PR tracking feature coming soon! This will show active AI-generated PRs and their status.")
        
        # Placeholder for PR data
        pr_data = [
            {
                'PR': '#123',
                'Job': 'build-pipeline',
                'Status': '🟡 Pending Review',
                'Created': '2 hours ago',
                'Confidence': '85%'
            },
            {
                'PR': '#124',
                'Job': 'test-suite',
                'Status': '🟢 Approved',
                'Created': '5 hours ago',
                'Confidence': '92%'
            }
        ]
        
        if pr_data:
            df = pd.DataFrame(pr_data)
            st.dataframe(df, use_container_width=True)
    
    def render_job_analysis_tool(self):
        """Render job analysis tool"""
        
        st.header("🔍 Job Analysis Tool")
        
        if not self.initialize_framework():
            return
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            job_name = st.text_input("Job Name", placeholder="e.g., build-pipeline")
            build_number = st.number_input("Build Number", min_value=1, value=1)
        
        with col2:
            st.write("")  # Spacer
            st.write("")  # Spacer
            analyze_button = st.button("🔍 Analyze", type="primary")
        
        if analyze_button and job_name and build_number:
            with st.spinner("Analyzing job..."):
                try:
                    # This would normally call the analysis function
                    # For now, show placeholder results
                    st.success("✅ Analysis completed!")
                    
                    # Show results
                    st.subheader("Analysis Results")
                    
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.metric("Failure Type", "Configuration Error")
                        st.metric("Confidence", "87%")
                        st.metric("Severity", "Medium")
                    
                    with col2:
                        st.metric("Recommended Action", "Create PR")
                        st.metric("Estimated Success", "78%")
                        st.metric("Risk Level", "Low")
                    
                    # Root cause analysis
                    st.subheader("Root Cause Analysis")
                    st.info("""
                    The build failed due to a missing environment variable in the Jenkins configuration.
                    The AI detected this pattern from previous similar failures and recommends updating
                    the configuration file to include the required variable.
                    """)
                    
                    # Proposed fix
                    st.subheader("Proposed Fix")
                    st.code("""
                    # Jenkinsfile update
                    environment {
                        REQUIRED_VAR = 'default_value'
                    }
                    """, language="groovy")
                
                except Exception as e:
                    st.error(f"❌ Analysis failed: {e}")
    
    def render_export_section(self):
        """Render data export section"""
        
        st.header("📤 Data Export")
        
        if not self.initialize_framework():
            return
        
        export_format = st.selectbox("Export Format", ["JSON", "CSV", "Excel"])
        data_type = st.selectbox("Data Type", ["Statistics", "Recent Failures", "All Patterns"])
        
        if st.button("📥 Export Data"):
            try:
                # Generate export data based on selection
                if data_type == "Statistics":
                    data = st.session_state.framework.get_statistics()
                elif data_type == "Recent Failures":
                    data = st.session_state.jenkins_client.get_failed_jobs(since_hours=24)
                else:
                    data = st.session_state.framework.rag_system.get_statistics()
                
                # Convert to appropriate format
                if export_format == "JSON":
                    json_data = json.dumps(data, indent=2, default=str)
                    st.download_button(
                        label="Download JSON",
                        data=json_data,
                        file_name=f"ai_devops_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                        mime="application/json"
                    )
                elif export_format == "CSV":
                    if isinstance(data, list):
                        df = pd.DataFrame(data)
                        csv_data = df.to_csv(index=False)
                        st.download_button(
                            label="Download CSV",
                            data=csv_data,
                            file_name=f"ai_devops_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                            mime="text/csv"
                        )
                    else:
                        st.warning("CSV export not available for this data type")
                
                st.success("✅ Export prepared successfully!")
            
            except Exception as e:
                st.error(f"❌ Export failed: {e}")
    
    def auto_refresh_check(self):
        """Check if auto refresh should trigger"""
        
        if st.session_state.auto_refresh and st.session_state.last_refresh:
            time_since_refresh = (datetime.now() - st.session_state.last_refresh).total_seconds()
            if time_since_refresh > 10:  # 10 second refresh
                st.session_state.last_refresh = datetime.now()
                st.rerun()
    
    def run(self):
        """Run the dashboard"""
        
        # Initialize framework
        self.initialize_framework()
        
        # Render components
        self.render_header()
        self.render_sidebar()
        
        # Main content tabs
        tab1, tab2, tab3, tab4, tab5 = st.tabs([
            "📊 Overview", "🕐 Activity", "🧠 Patterns", "🔀 PRs", "🔍 Tools"
        ])
        
        with tab1:
            self.render_overview_metrics()
        
        with tab2:
            self.render_recent_activity()
        
        with tab3:
            self.render_pattern_analysis()
        
        with tab4:
            self.render_active_prs()
        
        with tab5:
            self.render_job_analysis_tool()
            st.divider()
            self.render_export_section()
        
        # Auto refresh
        if st.session_state.auto_refresh:
            if st.session_state.last_refresh is None:
                st.session_state.last_refresh = datetime.now()
            else:
                self.auto_refresh_check()


def main():
    """Main dashboard entry point"""
    
    dashboard = Dashboard()
    dashboard.run()


if __name__ == "__main__":
    main()