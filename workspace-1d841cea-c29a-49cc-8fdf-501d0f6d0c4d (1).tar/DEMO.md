# 🚀 AI DevOps Framework - Demo Guide

## Quick Demo Setup

This guide walks you through setting up and demonstrating the AI DevOps Framework with sample data.

## Prerequisites

- Python 3.8+
- Groq API key
- Jenkins server (or use the demo mode)
- GitLab account (optional for full demo)

## 5-Minute Demo

### 1. Installation

```bash
# Clone and setup
git clone <repository>
cd ai-devops-jenkins-framework
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env with your Groq API key
```

### 2. Initialize System

```bash
# Initialize vector database with sample patterns
python scripts/init_vector_db.py

# Test connections
python main.py test
```

### 3. Launch Dashboard

```bash
# Start the monitoring dashboard
python main.py dashboard
```

Visit http://localhost:8501 to see the dashboard.

### 4. Demo Scenario

#### Sample Failure Analysis

The framework includes sample failure patterns for demonstration:

1. **Compilation Error**: Missing dependencies
2. **Test Timeout**: Network latency issues  
3. **Configuration Error**: Missing environment variables
4. **Security Issue**: Vulnerable dependencies
5. **Infrastructure Issue**: Database connectivity

#### Simulate a Failure

```bash
# Analyze a sample failure (demo mode)
python main.py analyze "demo-build-pipeline" 123
```

Expected output:
```
🔍 JENKINS FAILURE ANALYSIS
==================================================
Job: demo-build-pipeline
Build: #123
Status: FAILURE
Timestamp: 2024-01-01 12:00:00

🤖 AI Action Taken: CREATE_PR
✅ Success: True
⏱️  Execution Time: 2.34s
🔗 PR Created: https://gitlab.com/demo/project/-/merge_requests/45
```

## Dashboard Demo

### Overview Tab

- **Metrics**: Total actions, success rate, patterns learned
- **Action Distribution**: Pie chart of AI decisions
- **System Health**: Connection status indicators

### Activity Tab

- **Recent Failures**: List of recent Jenkins failures
- **AI Actions**: What the AI did for each failure
- **Success Tracking**: Visual indicators of success/failure

### Patterns Tab

- **Failure Types**: Bar chart of failure categories
- **Learning Progress**: Success rate over time
- **Pattern Effectiveness**: Which patterns work best

### PRs Tab

- **Active Pull Requests**: AI-generated PRs waiting for review
- **PR Status**: Open, merged, or closed PRs
- **Success Metrics**: PR merge success rates

### Tools Tab

- **Manual Analysis**: Analyze specific jobs
- **Data Export**: Export statistics and patterns
- **Configuration Testing**: Test system connections

## Advanced Demo Features

### 1. Real-time Monitoring

```bash
# Start monitoring (requires Jenkins connection)
python main.py monitor
```

The system will:
- Poll Jenkins every 30 seconds
- Automatically detect failures
- Process them through AI analysis
- Take appropriate actions

### 2. Webhook Integration

Start the webhook server for real-time notifications:

```bash
cd examples/webhook
python webhook_server.py
```

Configure Jenkins to send webhooks to:
```
http://localhost:8000/webhook/jenkins
```

### 3. Custom Pattern Creation

```python
from src.ai.rag_system import FailurePattern
from datetime import datetime

# Create custom pattern
pattern = FailurePattern(
    id="",
    job_name="my-app",
    failure_type="database_error",
    error_signature="Connection timeout to database",
    root_cause="Database server overloaded",
    solution_applied="Add connection pooling and retry logic",
    success_rate=0.9,
    occurrence_count=3,
    last_seen=datetime.now()
)

# Add to system
rag_system.add_failure_pattern(pattern)
```

### 4. Security Demonstration

The security checker will:

- Scan proposed code changes
- Check for forbidden patterns
- Run SAST analysis
- Test fixes in sandbox

```python
from src.security.security_checker import SecurityChecker

security = SecurityChecker(config)
risks = await security.assess_fix_security(fix_proposal)
print(f"Security risks found: {len(risks)}")
```

## Sample Scenarios

### Scenario 1: Auto-Fix Demonstration

**Failure**: Missing environment variable in Jenkins configuration

**AI Analysis**:
- Failure Type: Configuration Error
- Confidence: 92%
- Risk Level: Low

**Action**: Auto-fix applied
- Jenkins configuration updated
- Build retriggered automatically
- Success: Build passes

### Scenario 2: PR Creation Demonstration

**Failure**: Complex code issue requiring multiple file changes

**AI Analysis**:
- Failure Type: Compilation Error
- Confidence: 75%
- Risk Level: Medium

**Action**: PR created
- Branch: `fix/ai-auto-fix-20240101_120000`
- Files changed: 3
- PR includes detailed analysis and reasoning

### Scenario 3: Human Intervention Demonstration

**Failure**: Security vulnerability detected

**AI Analysis**:
- Failure Type: Security Issue
- Confidence: 60%
- Risk Level: High

**Action**: Human intervention required
- Incident report created
- Security team notified
- Detailed analysis provided

## Metrics to Showcase

### AI Performance

- **Accuracy**: Percentage of successful fixes
- **Confidence**: Average confidence scores
- **Speed**: Average processing time
- **Learning**: Improvement over time

### Business Impact

- **MTTR Reduction**: Mean Time To Recovery improvement
- **Developer Productivity**: Time saved on manual debugging
- **Failure Reduction**: Decrease in recurring failures
- **Quality Improvement**: Better code quality through AI suggestions

### System Health

- **Uptime**: Framework availability
- **Processing Queue**: Number of pending failures
- **Success Rate**: Overall success percentage
- **Error Rate**: Processing error frequency

## Customization Demo

### 1. Adjust Confidence Thresholds

```yaml
ai:
  confidence_threshold:
    auto_fix: 0.9      # More conservative
    pr_creation: 0.7   # Moderate confidence
    human_intervention: 0.3  # Earlier human review
```

### 2. Add Custom Security Rules

```yaml
security:
  forbidden_patterns:
    - "rm -rf"
    - "sudo"
    - "eval"
    - "exec"
    - "chmod 777"
    - "curl | sh"  # Custom rule
```

### 3. Configure Notifications

```yaml
monitoring:
  alert_channels:
    slack:
      webhook_url: "${SLACK_WEBHOOK_URL}"
      enabled: true
```

## Troubleshooting Demo Issues

### Common Demo Problems

1. **API Key Issues**
   ```bash
   export GROQ_API_KEY="your-key-here"
   ```

2. **Jenkins Connection**
   ```bash
   python main.py test  # Verify connection
   ```

3. **Vector Database**
   ```bash
   python scripts/init_vector_db.py  # Reinitialize
   ```

4. **Dashboard Not Loading**
   ```bash
   pip install streamlit  # Ensure installed
   python main.py dashboard  # Restart
   ```

## Production Readiness Demo

### 1. Scalability

- Show multiple concurrent failures
- Demonstrate queue handling
- Display performance metrics

### 2. Security

- Show security scanning in action
- Demonstrate sandbox testing
- Display audit logs

### 3. Integration

- Jenkins webhook integration
- GitLab PR workflow
- Slack notifications

### 4. Monitoring

- Real-time metrics
- Historical trends
- Alert configuration

## Next Steps

After the demo:

1. **Production Setup**: Follow the User Guide for production deployment
2. **Customization**: Tailor confidence thresholds and rules
3. **Integration**: Set up webhooks and notifications
4. **Training**: Train team on AI capabilities and limitations
5. **Monitoring**: Set up ongoing monitoring and alerting

## Support Resources

- **Documentation**: `/docs` folder
- **Examples**: `/examples` folder  
- **API Reference**: `docs/API_REFERENCE.md`
- **Architecture**: `docs/ARCHITECTURE.md`
- **User Guide**: `docs/USER_GUIDE.md`

This demo provides a comprehensive overview of the AI DevOps Framework capabilities, from basic failure analysis to advanced security and integration features.