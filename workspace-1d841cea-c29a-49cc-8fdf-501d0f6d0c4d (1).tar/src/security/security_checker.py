"""
Security and Compliance Checker
Validates proposed fixes for security risks and compliance issues
"""

import re
import subprocess
import tempfile
import os
from typing import Dict, List, Any, Optional
from pathlib import Path
from loguru import logger

from ..ai.ai_engine import FixProposal


class SecurityChecker:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.enable_sast = config['security'].get('enable_sast', True)
        self.enable_dast = config['security'].get('enable_dast', False)
        self.sandbox_execution = config['security'].get('sandbox_execution', True)
        self.max_code_changes = config['security'].get('max_code_changes', 1000)
        self.forbidden_patterns = config['security'].get('forbidden_patterns', [])
        
        # Compile forbidden patterns
        self.forbidden_regexes = [re.compile(pattern, re.IGNORECASE) for pattern in self.forbidden_patterns]
        
        logger.info("Security Checker initialized")
    
    async def assess_fix_security(self, fix_proposal: FixProposal) -> List[str]:
        """Assess security risks of a proposed fix"""
        
        risks = []
        
        try:
            # Check for forbidden patterns
            pattern_risks = self._check_forbidden_patterns(fix_proposal)
            risks.extend(pattern_risks)
            
            # Check code change volume
            volume_risks = self._check_change_volume(fix_proposal)
            risks.extend(volume_risks)
            
            # Check file permissions and access
            access_risks = self._check_file_access(fix_proposal)
            risks.extend(access_risks)
            
            # Run SAST if enabled
            if self.enable_sast:
                sast_risks = await self._run_sast_analysis(fix_proposal)
                risks.extend(sast_risks)
            
            # Check command security
            command_risks = self._check_command_security(fix_proposal)
            risks.extend(command_risks)
            
            # Check configuration security
            config_risks = self._check_configuration_security(fix_proposal)
            risks.extend(config_risks)
            
            logger.info(f"Security assessment found {len(risks)} risks")
            return risks
            
        except Exception as e:
            logger.error(f"Error in security assessment: {e}")
            return [f"Security assessment failed: {str(e)}"]
    
    def _check_forbidden_patterns(self, fix_proposal: FixProposal) -> List[str]:
        """Check for forbidden patterns in fix proposal"""
        
        risks = []
        
        # Check in file changes
        for file_change in fix_proposal.file_changes:
            content = file_change.get('content', '')
            for pattern, regex in zip(self.forbidden_patterns, self.forbidden_regexes):
                if regex.search(content):
                    risks.append(f"Forbidden pattern '{pattern}' found in {file_change['path']}")
        
        # Check in commands
        for command in fix_proposal.commands_to_run:
            for pattern, regex in zip(self.forbidden_patterns, self.forbidden_regexes):
                if regex.search(command):
                    risks.append(f"Forbidden pattern '{pattern}' found in command: {command}")
        
        return risks
    
    def _check_change_volume(self, fix_proposal: FixProposal) -> List[str]:
        """Check if the volume of changes is acceptable"""
        
        risks = []
        total_lines = 0
        
        for file_change in fix_proposal.file_changes:
            content = file_change.get('content', '')
            lines = len(content.splitlines())
            total_lines += lines
            
            if lines > self.max_code_changes:
                risks.append(f"Large file change detected: {file_change['path']} ({lines} lines)")
        
        if total_lines > self.max_code_changes * 2:  # Allow more total changes across files
            risks.append(f"Total changes too large: {total_lines} lines")
        
        return risks
    
    def _check_file_access(self, fix_proposal: FixProposal) -> List[str]:
        """Check for risky file access patterns"""
        
        risks = []
        risky_paths = [
            '/etc/', '/usr/bin/', '/bin/', '/sbin/', '/root/',
            'passwd', 'shadow', 'sudoers', 'ssh/', '.ssh/',
            'key', 'secret', 'token', 'password'
        ]
        
        for file_change in fix_proposal.file_changes:
            file_path = file_change['path'].lower()
            
            for risky_path in risky_paths:
                if risky_path in file_path:
                    risks.append(f"Risky file path access: {file_change['path']}")
                    break
        
        return risks
    
    def _check_command_security(self, fix_proposal: FixProposal) -> List[str]:
        """Check security of commands to be executed"""
        
        risks = []
        dangerous_commands = [
            'rm -rf', 'sudo', 'su', 'chmod 777', 'chown',
            'curl | sh', 'wget | sh', 'eval', 'exec',
            'iptables', 'ufw', 'firewall',
            'systemctl', 'service', 'init.d'
        ]
        
        for command in fix_proposal.commands_to_run:
            command_lower = command.lower()
            
            for dangerous in dangerous_commands:
                if dangerous in command_lower:
                    risks.append(f"Dangerous command detected: {command}")
        
        # Check for pipeline/redirect risks
        if any('|' in cmd or '>' in cmd or '>>' in cmd for cmd in fix_proposal.commands_to_run):
            risks.append("Command contains potentially unsafe redirects or pipes")
        
        return risks
    
    def _check_configuration_security(self, fix_proposal: FixProposal) -> List[str]:
        """Check security of configuration changes"""
        
        risks = []
        config_changes = fix_proposal.configuration_changes
        
        # Check Jenkins config changes
        jenkins_config = config_changes.get('jenkins_config', {})
        if jenkins_config:
            # Check for insecure settings
            if 'disableSecurity' in str(jenkins_config).lower():
                risks.append("Jenkins security disable detected")
            
            if 'authorization' in str(jenkins_config).lower() and 'unsecured' in str(jenkins_config).lower():
                risks.append("Unsecured authorization configuration detected")
        
        # Check environment variables
        env_vars = config_changes.get('environment_vars', {})
        for var_name, var_value in env_vars.items():
            if any(secret in var_name.lower() for secret in ['password', 'secret', 'key', 'token']):
                if var_value and not self._is_secure_value(var_value):
                    risks.append(f"Insecure environment variable: {var_name}")
        
        return risks
    
    async def _run_sast_analysis(self, fix_proposal: FixProposal) -> List[str]:
        """Run Static Application Security Testing"""
        
        risks = []
        
        try:
            # Create temporary directory for analysis
            with tempfile.TemporaryDirectory() as temp_dir:
                temp_path = Path(temp_dir)
                
                # Write files to temporary directory
                for file_change in fix_proposal.file_changes:
                    if file_change['action'] in ['update', 'create']:
                        file_path = temp_path / file_change['path']
                        file_path.parent.mkdir(parents=True, exist_ok=True)
                        
                        with open(file_path, 'w') as f:
                            f.write(file_change.get('content', ''))
                
                # Run Bandit for Python files
                python_files = list(temp_path.rglob('*.py'))
                if python_files:
                    bandit_risks = await self._run_bandit(python_files)
                    risks.extend(bandit_risks)
                
                # Run Semgrep if available
                if self._is_tool_available('semgrep'):
                    semgrep_risks = await self._run_semgrep(temp_dir)
                    risks.extend(semgrep_risks)
                
                # Run Safety for dependency checks
                if any(temp_path.rglob('requirements.txt')) or any(temp_path.rglob('setup.py')):
                    safety_risks = await self._run_safety(temp_dir)
                    risks.extend(safety_risks)
        
        except Exception as e:
            logger.error(f"SAST analysis failed: {e}")
            risks.append(f"SAST analysis failed: {str(e)}")
        
        return risks
    
    async def _run_bandit(self, python_files: List[Path]) -> List[str]:
        """Run Bandit security analysis on Python files"""
        
        risks = []
        
        try:
            for file_path in python_files:
                cmd = ['bandit', '-f', 'json', str(file_path)]
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
                
                if result.returncode != 0 and result.stdout:
                    try:
                        import json
                        bandit_output = json.loads(result.stdout)
                        
                        for issue in bandit_output.get('results', []):
                            if issue.get('issue_severity') in ['HIGH', 'MEDIUM']:
                                risks.append(
                                    f"Bandit {issue['issue_severity']}: {issue['issue_text']} "
                                    f"in {file_path.name}:{issue.get('line_number', 'unknown')}"
                                )
                    except json.JSONDecodeError:
                        logger.warning(f"Failed to parse Bandit output for {file_path}")
        
        except subprocess.TimeoutExpired:
            risks.append("Bandit analysis timed out")
        except FileNotFoundError:
            logger.info("Bandit not available for security analysis")
        except Exception as e:
            logger.error(f"Error running Bandit: {e}")
        
        return risks
    
    async def _run_semgrep(self, scan_dir: str) -> List[str]:
        """Run Semgrep security analysis"""
        
        risks = []
        
        try:
            cmd = ['semgrep', '--config=auto', '--json', scan_dir]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            
            if result.stdout:
                try:
                    import json
                    semgrep_output = json.loads(result.stdout)
                    
                    for result in semgrep_output.get('results', []):
                        metadata = result.get('metadata', {})
                        if metadata.get('impact') in ['HIGH', 'MEDIUM']:
                            risks.append(
                                f"Semgrep {metadata.get('impact', 'UNKNOWN')}: "
                                f"{result.get('message', 'Unknown issue')} "
                                f"in {result.get('path', 'unknown')}"
                            )
                except json.JSONDecodeError:
                    logger.warning("Failed to parse Semgrep output")
        
        except subprocess.TimeoutExpired:
            risks.append("Semgrep analysis timed out")
        except Exception as e:
            logger.error(f"Error running Semgrep: {e}")
        
        return risks
    
    async def _run_safety(self, scan_dir: str) -> List[str]:
        """Run Safety dependency vulnerability check"""
        
        risks = []
        
        try:
            # Look for requirements files
            requirements_files = list(Path(scan_dir).rglob('requirements*.txt'))
            
            for req_file in requirements_files:
                cmd = ['safety', 'check', '--json', '--file', str(req_file)]
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
                
                if result.stdout:
                    try:
                        import json
                        safety_output = json.loads(result.stdout)
                        
                        for vuln in safety_output:
                            risks.append(
                                f"Safety vulnerability: {vuln.get('advisory', 'Unknown')} "
                                f"in package {vuln.get('package', 'unknown')}"
                            )
                    except json.JSONDecodeError:
                        logger.warning(f"Failed to parse Safety output for {req_file}")
        
        except subprocess.TimeoutExpired:
            risks.append("Safety analysis timed out")
        except FileNotFoundError:
            logger.info("Safety not available for dependency analysis")
        except Exception as e:
            logger.error(f"Error running Safety: {e}")
        
        return risks
    
    def _is_tool_available(self, tool_name: str) -> bool:
        """Check if a security tool is available"""
        try:
            subprocess.run([tool_name, '--version'], capture_output=True, check=True, timeout=5)
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False
    
    def _is_secure_value(self, value: str) -> bool:
        """Check if a value appears to be securely stored"""
        
        # Check for common insecure patterns
        insecure_patterns = [
            r'^password$', r'^secret$', r'^key$',
            r'^123', r'^test', r'^admin',
            r'^changeme', r'^default'
        ]
        
        value_lower = value.lower()
        for pattern in insecure_patterns:
            if re.match(pattern, value_lower):
                return False
        
        # Check length
        if len(value) < 8:
            return False
        
        return True
    
    def create_sandbox_environment(self) -> Optional[str]:
        """Create a sandboxed environment for testing fixes"""
        
        if not self.sandbox_execution:
            return None
        
        try:
            # Create temporary directory as sandbox
            sandbox_dir = tempfile.mkdtemp(prefix='ai_devops_sandbox_')
            
            # Set restrictive permissions
            os.chmod(sandbox_dir, 0o700)
            
            logger.info(f"Created sandbox environment: {sandbox_dir}")
            return sandbox_dir
            
        except Exception as e:
            logger.error(f"Failed to create sandbox: {e}")
            return None
    
    def cleanup_sandbox(self, sandbox_dir: str):
        """Clean up sandbox environment"""
        
        try:
            import shutil
            shutil.rmtree(sandbox_dir)
            logger.info(f"Cleaned up sandbox: {sandbox_dir}")
        except Exception as e:
            logger.error(f"Failed to cleanup sandbox: {e}")
    
    async def test_fix_in_sandbox(self, fix_proposal: FixProposal) -> Dict[str, Any]:
        """Test a fix proposal in a sandboxed environment"""
        
        sandbox_dir = None
        test_results = {
            'success': False,
            'errors': [],
            'warnings': [],
            'execution_time': 0
        }
        
        try:
            import time
            start_time = time.time()
            
            # Create sandbox
            sandbox_dir = self.create_sandbox_environment()
            if not sandbox_dir:
                test_results['errors'].append("Failed to create sandbox environment")
                return test_results
            
            sandbox_path = Path(sandbox_dir)
            
            # Apply file changes in sandbox
            for file_change in fix_proposal.file_changes:
                if file_change['action'] in ['update', 'create']:
                    file_path = sandbox_path / file_change['path']
                    file_path.parent.mkdir(parents=True, exist_ok=True)
                    
                    with open(file_path, 'w') as f:
                        f.write(file_change.get('content', ''))
            
            # Test commands in sandbox
            for command in fix_proposal.commands_to_run:
                try:
                    # Modify command to run in sandbox
                    sandbox_command = f"cd {sandbox_dir} && {command}"
                    
                    result = subprocess.run(
                        sandbox_command, 
                        shell=True, 
                        capture_output=True, 
                        text=True, 
                        timeout=30,
                        cwd=sandbox_dir
                    )
                    
                    if result.returncode != 0:
                        test_results['errors'].append(
                            f"Command failed: {command} - {result.stderr}"
                        )
                except subprocess.TimeoutExpired:
                    test_results['errors'].append(f"Command timed out: {command}")
                except Exception as e:
                    test_results['errors'].append(f"Command error: {command} - {str(e)}")
            
            test_results['success'] = len(test_results['errors']) == 0
            test_results['execution_time'] = time.time() - start_time
            
        except Exception as e:
            test_results['errors'].append(f"Sandbox test failed: {str(e)}")
        finally:
            if sandbox_dir:
                self.cleanup_sandbox(sandbox_dir)
        
        return test_results