"""
Configuration Loader
Handles loading and validating configuration from YAML files and environment variables
"""

import os
import yaml
from typing import Dict, Any, Optional
from pathlib import Path
from loguru import logger
from dotenv import load_dotenv


class ConfigLoader:
    def __init__(self, config_path: str = "config.yaml"):
        self.config_path = Path(config_path)
        self.config = {}
        
        # Load environment variables
        load_dotenv()
        
        # Load configuration
        self._load_config()
        self._validate_config()
        self._substitute_env_vars()
    
    def _load_config(self):
        """Load configuration from YAML file"""
        try:
            if self.config_path.exists():
                with open(self.config_path, 'r') as f:
                    self.config = yaml.safe_load(f)
                logger.info(f"Configuration loaded from {self.config_path}")
            else:
                logger.warning(f"Configuration file {self.config_path} not found, using defaults")
                self.config = self._get_default_config()
        except Exception as e:
            logger.error(f"Error loading configuration: {e}")
            self.config = self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration"""
        return {
            'jenkins': {
                'url': os.getenv('JENKINS_URL', 'http://localhost:8080'),
                'username': os.getenv('JENKINS_USERNAME', ''),
                'api_token': os.getenv('JENKINS_API_TOKEN', ''),
                'webhook_secret': os.getenv('JENKINS_WEBHOOK_SECRET', ''),
                'poll_interval': 30,
                'max_retries': 3,
                'timeout': 300
            },
            'gitlab': {
                'url': os.getenv('GITLAB_URL', 'https://gitlab.com'),
                'token': os.getenv('GITLAB_TOKEN', ''),
                'default_branch': 'main',
                'pr_auto_merge': False,
                'require_approval': True
            },
            'ai': {
                'groq_api_key': os.getenv('GROQ_API_KEY', ''),
                'model': 'llama3-70b-8192',
                'temperature': 0.1,
                'max_tokens': 4096,
                'confidence_threshold': {
                    'auto_fix': 0.8,
                    'pr_creation': 0.6,
                    'human_intervention': 0.4
                }
            },
            'vector_db': {
                'type': 'faiss',
                'path': './data/vector_db',
                'embedding_model': 'sentence-transformers/all-MiniLM-L6-v2',
                'dimension': 384,
                'index_type': 'flat'
            },
            'monitoring': {
                'enabled': True,
                'log_level': 'INFO',
                'metrics_retention_days': 30,
                'alert_channels': {
                    'slack': {
                        'webhook_url': os.getenv('SLACK_WEBHOOK_URL', ''),
                        'enabled': False
                    },
                    'email': {
                        'smtp_server': os.getenv('SMTP_SERVER', ''),
                        'enabled': False
                    }
                }
            },
            'security': {
                'enable_sast': True,
                'enable_dast': False,
                'sandbox_execution': True,
                'max_code_changes': 1000,
                'forbidden_patterns': [
                    'rm -rf',
                    'sudo',
                    'chmod 777'
                ]
            },
            'learning': {
                'feedback_collection': True,
                'auto_retrain': True,
                'retrain_interval': 24,
                'min_samples_for_retrain': 50
            },
            'dashboard': {
                'host': 'localhost',
                'port': 8501,
                'refresh_interval': 5,
                'max_display_items': 100
            },
            'paths': {
                'logs': './logs',
                'data': './data',
                'temp': './temp',
                'backups': './backups'
            }
        }
    
    def _validate_config(self):
        """Validate configuration values"""
        errors = []
        
        # Validate required fields
        required_fields = [
            ('jenkins.url', str),
            ('jenkins.username', str),
            ('jenkins.api_token', str),
            ('gitlab.token', str),
            ('ai.groq_api_key', str)
        ]
        
        for field_path, field_type in required_fields:
            value = self._get_nested_value(field_path)
            if not value or (field_type == str and not value.strip()):
                errors.append(f"Missing required configuration: {field_path}")
        
        # Validate numeric ranges
        numeric_ranges = {
            'jenkins.poll_interval': (1, 3600),
            'ai.temperature': (0.0, 2.0),
            'ai.confidence_threshold.auto_fix': (0.0, 1.0),
            'ai.confidence_threshold.pr_creation': (0.0, 1.0),
            'ai.confidence_threshold.human_intervention': (0.0, 1.0)
        }
        
        for field_path, (min_val, max_val) in numeric_ranges.items():
            value = self._get_nested_value(field_path)
            if value is not None and not (min_val <= value <= max_val):
                errors.append(f"Invalid value for {field_path}: {value} (must be between {min_val} and {max_val})")
        
        # Validate confidence threshold ordering
        auto_fix = self._get_nested_value('ai.confidence_threshold.auto_fix')
        pr_creation = self._get_nested_value('ai.confidence_threshold.pr_creation')
        human_intervention = self._get_nested_value('ai.confidence_threshold.human_intervention')
        
        if not (auto_fix >= pr_creation >= human_intervention):
            errors.append("Confidence thresholds must be ordered: auto_fix >= pr_creation >= human_intervention")
        
        if errors:
            raise ValueError(f"Configuration validation failed: {'; '.join(errors)}")
    
    def _substitute_env_vars(self):
        """Substitute environment variables in configuration"""
        def substitute_recursive(obj):
            if isinstance(obj, dict):
                return {k: substitute_recursive(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [substitute_recursive(item) for item in obj]
            elif isinstance(obj, str) and obj.startswith('${') and obj.endswith('}'):
                env_var = obj[2:-1]
                default_value = ''
                if ':' in env_var:
                    env_var, default_value = env_var.split(':', 1)
                return os.getenv(env_var, default_value)
            else:
                return obj
        
        self.config = substitute_recursive(self.config)
    
    def _get_nested_value(self, path: str) -> Any:
        """Get nested configuration value by dot-separated path"""
        keys = path.split('.')
        value = self.config
        
        for key in keys:
            if isinstance(value, dict) and key in value:
                value = value[key]
            else:
                return None
        
        return value
    
    def get(self, path: str, default: Any = None) -> Any:
        """Get configuration value by path"""
        value = self._get_nested_value(path)
        return value if value is not None else default
    
    def set(self, path: str, value: Any):
        """Set configuration value by path"""
        keys = path.split('.')
        config = self.config
        
        for key in keys[:-1]:
            if key not in config:
                config[key] = {}
            config = config[key]
        
        config[keys[-1]] = value
    
    def save(self, path: Optional[str] = None):
        """Save configuration to file"""
        save_path = Path(path) if path else self.config_path
        
        try:
            with open(save_path, 'w') as f:
                yaml.dump(self.config, f, default_flow_style=False, indent=2)
            logger.info(f"Configuration saved to {save_path}")
        except Exception as e:
            logger.error(f"Failed to save configuration: {e}")
    
    def create_directories(self):
        """Create necessary directories based on configuration"""
        paths = self.get('paths', {})
        
        for path_name, path_value in paths.items():
            path_obj = Path(path_value)
            path_obj.mkdir(parents=True, exist_ok=True)
            logger.debug(f"Created directory: {path_value}")
    
    def get_jenkins_config(self) -> Dict[str, Any]:
        """Get Jenkins configuration"""
        return self.get('jenkins', {})
    
    def get_gitlab_config(self) -> Dict[str, Any]:
        """Get GitLab configuration"""
        return self.get('gitlab', {})
    
    def get_ai_config(self) -> Dict[str, Any]:
        """Get AI configuration"""
        return self.get('ai', {})
    
    def get_vector_db_config(self) -> Dict[str, Any]:
        """Get vector database configuration"""
        return self.get('vector_db', {})
    
    def get_security_config(self) -> Dict[str, Any]:
        """Get security configuration"""
        return self.get('security', {})
    
    def get_monitoring_config(self) -> Dict[str, Any]:
        """Get monitoring configuration"""
        return self.get('monitoring', {})
    
    def get_dashboard_config(self) -> Dict[str, Any]:
        """Get dashboard configuration"""
        return self.get('dashboard', {})
    
    def is_monitoring_enabled(self) -> bool:
        """Check if monitoring is enabled"""
        return self.get('monitoring.enabled', True)
    
    def is_slack_enabled(self) -> bool:
        """Check if Slack notifications are enabled"""
        return self.get('monitoring.alert_channels.slack.enabled', False)
    
    def get_slack_webhook(self) -> str:
        """Get Slack webhook URL"""
        return self.get('monitoring.alert_channels.slack.webhook_url', '')
    
    def __getitem__(self, key: str) -> Any:
        """Allow dictionary-style access"""
        return self.config[key]
    
    def __contains__(self, key: str) -> bool:
        """Allow 'in' operator"""
        return key in self.config