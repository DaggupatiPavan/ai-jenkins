"""
Decision and Action Engine
Core engine that decides between self-healing, PR creation, or human intervention
"""

import asyncio
import json
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime
from dataclasses import dataclass
from enum import Enum
from loguru import logger

from ..ai.ai_engine import AIEngine, FailureAnalysis, FixProposal
from ..ai.rag_system import RAGSystem, ResolutionHistory
from ..integrations.jenkins_client import JenkinsClient, JenkinsBuild
from ..integrations.gitlab_client import GitLabClient
from ..security.security_checker import SecurityChecker


class ActionType(Enum):
    AUTO_FIX = "auto_fix"
    CREATE_PR = "create_pr"
    HUMAN_INTERVENTION = "human_intervention"
    MONITOR_ONLY = "monitor_only"


@dataclass
class DecisionResult:
    action: ActionType
    confidence: float
    reasoning: str
    fix_proposal: Optional[FixProposal] = None
    security_risks: List[str] = None
    estimated_success_rate: float = 0.0
    requires_approval: bool = False
    metadata: Dict[str, Any] = None


@dataclass
class ActionResult:
    success: bool
    action_taken: ActionType
    result_details: Dict[str, Any]
    error_message: Optional[str] = None
    execution_time: float = 0.0
    pr_url: Optional[str] = None
    build_retriggered: bool = False


class DecisionEngine:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.ai_engine = AIEngine(config)
        self.rag_system = RAGSystem(config)
        self.jenkins_client = JenkinsClient(config)
        self.gitlab_client = GitLabClient(config)
        self.security_checker = SecurityChecker(config)
        
        # Configuration thresholds
        self.auto_fix_threshold = config['ai']['confidence_threshold']['auto_fix']
        self.pr_threshold = config['ai']['confidence_threshold']['pr_creation']
        self.human_threshold = config['ai']['confidence_threshold']['human_intervention']
        
        # Action history
        self.action_history = []
        
        logger.info("Decision Engine initialized")
    
    async def process_failure(self, jenkins_build: JenkinsBuild, 
                            project_id: str = None) -> ActionResult:
        """Process a Jenkins build failure and determine appropriate action"""
        start_time = datetime.now()
        
        try:
            logger.info(f"Processing failure for {jenkins_build.job_name}#{jenkins_build.build_number}")
            
            # Step 1: Analyze the failure
            failure_analysis = await self.ai_engine.analyze_failure(jenkins_build)
            
            # Step 2: Get historical context from RAG system
            historical_suggestions = self.rag_system.get_resolution_suggestions(
                {
                    'job_name': failure_analysis.job_name,
                    'failure_type': failure_analysis.failure_type,
                    'root_cause': failure_analysis.root_cause,
                    'error_patterns': failure_analysis.error_patterns,
                    'affected_components': failure_analysis.affected_components
                }
            )
            
            # Step 3: Generate fix proposal
            fix_proposal = await self.ai_engine.generate_fix(
                failure_analysis, jenkins_build, 
                code_context={'historical_suggestions': historical_suggestions}
            )
            
            # Step 4: Assess auto-fix feasibility
            assessment = await self.ai_engine.assess_auto_fix_feasibility(
                failure_analysis, fix_proposal, historical_suggestions
            )
            
            # Step 5: Security assessment
            security_risks = await self.security_checker.assess_fix_security(fix_proposal)
            
            # Step 6: Make final decision
            decision = self._make_decision(
                failure_analysis, fix_proposal, assessment, security_risks, historical_suggestions
            )
            
            # Step 7: Execute action
            action_result = await self._execute_action(
                decision, jenkins_build, failure_analysis, project_id
            )
            
            # Step 8: Record outcome for learning
            await self._record_outcome(
                failure_analysis, decision, action_result, historical_suggestions
            )
            
            execution_time = (datetime.now() - start_time).total_seconds()
            action_result.execution_time = execution_time
            
            logger.info(f"Failure processing completed in {execution_time:.2f}s: {action_result.action_taken.value}")
            return action_result
            
        except Exception as e:
            logger.error(f"Error processing failure: {e}")
            return ActionResult(
                success=False,
                action_taken=ActionType.HUMAN_INTERVENTION,
                result_details={'error': str(e)},
                error_message=str(e),
                execution_time=(datetime.now() - start_time).total_seconds()
            )
    
    def _make_decision(self, failure_analysis: FailureAnalysis, 
                      fix_proposal: FixProposal, assessment: Dict[str, Any],
                      security_risks: List[str], 
                      historical_suggestions: List[Dict[str, Any]]) -> DecisionResult:
        """Make final decision on action to take"""
        
        # Base confidence from AI assessment
        base_confidence = assessment.get('confidence', 0.0)
        
        # Adjust confidence based on historical success
        if historical_suggestions:
            best_match = historical_suggestions[0]
            historical_success_rate = best_match.get('historical_success_rate', 0.0)
            similarity_score = best_match.get('similarity_score', 0.0)
            
            # Weight historical success
            adjusted_confidence = (base_confidence * 0.6) + (historical_success_rate * similarity_score * 0.4)
        else:
            adjusted_confidence = base_confidence
        
        # Security risk adjustment
        if security_risks:
            security_penalty = len(security_risks) * 0.1
            adjusted_confidence = max(0, adjusted_confidence - security_penalty)
        
        # Determine action based on confidence
        if adjusted_confidence >= self.auto_fix_threshold and not security_risks:
            action = ActionType.AUTO_FIX
            requires_approval = False
        elif adjusted_confidence >= self.pr_threshold:
            action = ActionType.CREATE_PR
            requires_approval = True
        else:
            action = ActionType.HUMAN_INTERVENTION
            requires_approval = True
        
        # Special cases for certain failure types
        if failure_analysis.failure_type in ['security_issue', 'infrastructure_issue']:
            action = ActionType.HUMAN_INTERVENTION
            requires_approval = True
        elif failure_analysis.severity == 'critical' and security_risks:
            action = ActionType.HUMAN_INTERVENTION
            requires_approval = True
        
        # Build reasoning
        reasoning = self._build_reasoning(
            failure_analysis, fix_proposal, assessment, security_risks, 
            historical_suggestions, adjusted_confidence
        )
        
        return DecisionResult(
            action=action,
            confidence=adjusted_confidence,
            reasoning=reasoning,
            fix_proposal=fix_proposal,
            security_risks=security_risks,
            estimated_success_rate=fix_proposal.estimated_success_rate,
            requires_approval=requires_approval,
            metadata={
                'base_confidence': base_confidence,
                'historical_suggestions_count': len(historical_suggestions),
                'security_risks_count': len(security_risks),
                'assessment': assessment
            }
        )
    
    async def _execute_action(self, decision: DecisionResult, 
                            jenkins_build: JenkinsBuild,
                            failure_analysis: FailureAnalysis,
                            project_id: str = None) -> ActionResult:
        """Execute the decided action"""
        
        try:
            if decision.action == ActionType.AUTO_FIX:
                return await self._execute_auto_fix(
                    decision, jenkins_build, failure_analysis
                )
            elif decision.action == ActionType.CREATE_PR:
                return await self._execute_pr_creation(
                    decision, jenkins_build, failure_analysis, project_id
                )
            elif decision.action == ActionType.HUMAN_INTERVENTION:
                return await self._execute_human_intervention(
                    decision, jenkins_build, failure_analysis
                )
            else:
                return ActionResult(
                    success=True,
                    action_taken=ActionType.MONITOR_ONLY,
                    result_details={'message': 'Monitoring only - no action taken'}
                )
                
        except Exception as e:
            logger.error(f"Error executing action {decision.action}: {e}")
            return ActionResult(
                success=False,
                action_taken=decision.action,
                result_details={'error': str(e)},
                error_message=str(e)
            )
    
    async def _execute_auto_fix(self, decision: DecisionResult,
                              jenkins_build: JenkinsBuild,
                              failure_analysis: FailureAnalysis) -> ActionResult:
        """Execute automatic fix"""
        
        try:
            logger.info(f"Executing auto-fix for {jenkins_build.job_name}")
            
            fix_proposal = decision.fix_proposal
            
            # Apply configuration changes
            if fix_proposal.configuration_changes:
                jenkins_config_changes = fix_proposal.configuration_changes.get('jenkins_config', {})
                if jenkins_config_changes:
                    # Update Jenkins job configuration
                    current_config = self.jenkins_client.get_job_config(jenkins_build.job_name)
                    if current_config:
                        # Apply changes to config (implementation depends on specific changes)
                        success = self.jenkins_client.update_job_config(
                            jenkins_build.job_name, current_config
                        )
                        if not success:
                            raise Exception("Failed to update Jenkins configuration")
            
            # Execute commands if any
            for command in fix_proposal.commands_to_run:
                # Execute command in sandboxed environment
                # This would need proper sandboxing implementation
                logger.info(f"Would execute command: {command}")
                # For safety, we'll skip actual command execution in this version
            
            # Retrigger the build
            build_retriggered = self.jenkins_client.trigger_build(
                jenkins_build.job_name,
                fix_proposal.configuration_changes.get('environment_vars', {})
            )
            
            if not build_retriggered:
                raise Exception("Failed to retrigger Jenkins build")
            
            return ActionResult(
                success=True,
                action_taken=ActionType.AUTO_FIX,
                result_details={
                    'fix_applied': True,
                    'configuration_changes': len(fix_proposal.configuration_changes),
                    'commands_executed': len(fix_proposal.commands_to_run),
                    'build_retriggered': True
                },
                build_retriggered=True
            )
            
        except Exception as e:
            logger.error(f"Auto-fix failed: {e}")
            return ActionResult(
                success=False,
                action_taken=ActionType.AUTO_FIX,
                result_details={'error': str(e)},
                error_message=str(e)
            )
    
    async def _execute_pr_creation(self, decision: DecisionResult,
                                 jenkins_build: JenkinsBuild,
                                 failure_analysis: FailureAnalysis,
                                 project_id: str) -> ActionResult:
        """Create pull request with proposed fix"""
        
        try:
            if not project_id:
                raise Exception("Project ID required for PR creation")
            
            logger.info(f"Creating PR for {jenkins_build.job_name}")
            
            # Prepare issue analysis and fix proposal for GitLab
            issue_analysis = {
                'job_name': failure_analysis.job_name,
                'build_number': failure_analysis.build_number,
                'failure_type': failure_analysis.failure_type,
                'root_cause': failure_analysis.root_cause,
                'confidence': decision.confidence,
                'reasoning_trace': decision.reasoning,
                'error_message': jenkins_build.console_log[:500] + '...' if len(jenkins_build.console_log) > 500 else jenkins_build.console_log,
                'git_commit': jenkins_build.git_commit
            }
            
            proposed_fix = {
                'solution_description': decision.fix_proposal.solution_description,
                'file_changes': decision.fix_proposal.file_changes,
                'confidence': decision.fix_proposal.confidence,
                'risks': decision.fix_proposal.risks
            }
            
            # Create PR
            pr = self.gitlab_client.create_fix_pr(project_id, issue_analysis, proposed_fix)
            
            if not pr:
                raise Exception("Failed to create GitLab PR")
            
            return ActionResult(
                success=True,
                action_taken=ActionType.CREATE_PR,
                result_details={
                    'pr_created': True,
                    'pr_id': pr.iid,
                    'pr_url': pr.web_url,
                    'files_changed': len(decision.fix_proposal.file_changes)
                },
                pr_url=pr.web_url
            )
            
        except Exception as e:
            logger.error(f"PR creation failed: {e}")
            return ActionResult(
                success=False,
                action_taken=ActionType.CREATE_PR,
                result_details={'error': str(e)},
                error_message=str(e)
            )
    
    async def _execute_human_intervention(self, decision: DecisionResult,
                                        jenkins_build: JenkinsBuild,
                                        failure_analysis: FailureAnalysis) -> ActionResult:
        """Handle cases requiring human intervention"""
        
        try:
            logger.info(f"Requiring human intervention for {jenkins_build.job_name}")
            
            # Create detailed incident report
            incident_report = {
                'job_name': jenkins_build.job_name,
                'build_number': jenkins_build.build_number,
                'failure_type': failure_analysis.failure_type,
                'severity': failure_analysis.severity,
                'root_cause': failure_analysis.root_cause,
                'confidence': decision.confidence,
                'reasoning': decision.reasoning,
                'security_risks': decision.security_risks,
                'suggested_fixes': failure_analysis.suggested_fixes,
                'requires_approval': decision.requires_approval,
                'timestamp': datetime.now().isoformat()
            }
            
            # Store incident report
            incident_file = f"data/incidents/{jenkins_build.job_name}_{jenkins_build.build_number}_{datetime.now().timestamp()}.json"
            import os
            os.makedirs(os.path.dirname(incident_file), exist_ok=True)
            with open(incident_file, 'w') as f:
                json.dump(incident_report, f, indent=2)
            
            # Send notification (if configured)
            await self._send_notification(incident_report)
            
            return ActionResult(
                success=True,
                action_taken=ActionType.HUMAN_INTERVENTION,
                result_details={
                    'incident_report_created': True,
                    'incident_file': incident_file,
                    'notification_sent': True,
                    'requires_approval': decision.requires_approval
                }
            )
            
        except Exception as e:
            logger.error(f"Human intervention setup failed: {e}")
            return ActionResult(
                success=False,
                action_taken=ActionType.HUMAN_INTERVENTION,
                result_details={'error': str(e)},
                error_message=str(e)
            )
    
    def _build_reasoning(self, failure_analysis: FailureAnalysis,
                        fix_proposal: FixProposal, assessment: Dict[str, Any],
                        security_risks: List[str], historical_suggestions: List[Dict[str, Any]],
                        confidence: float) -> str:
        """Build detailed reasoning for the decision"""
        
        reasoning_parts = [
            f"Failure Analysis: {failure_analysis.failure_type} - {failure_analysis.root_cause}",
            f"AI Confidence: {confidence:.2%}",
            f"Fix Complexity: {len(fix_proposal.file_changes)} file changes, {len(fix_proposal.commands_to_run)} commands"
        ]
        
        if security_risks:
            reasoning_parts.append(f"Security Risks: {', '.join(security_risks)}")
        
        if historical_suggestions:
            best_match = historical_suggestions[0]
            reasoning_parts.append(
                f"Historical Context: {best_match.get('historical_success_rate', 0):.1%} success rate for similar issues"
            )
        
        if failure_analysis.severity == 'critical':
            reasoning_parts.append("Critical severity requires careful consideration")
        
        return " | ".join(reasoning_parts)
    
    async def _record_outcome(self, failure_analysis: FailureAnalysis,
                            decision: DecisionResult, action_result: ActionResult,
                            historical_suggestions: List[Dict[str, Any]]):
        """Record outcome for learning"""
        
        try:
            # Create or update failure pattern
            from ..ai.rag_system import FailurePattern, ResolutionHistory
            
            # Check if similar pattern exists
            similar_patterns = self.rag_system.search_similar_patterns(
                f"{failure_analysis.failure_type} {failure_analysis.root_cause}", top_k=1
            )
            
            if similar_patterns and similar_patterns[0][1] > 0.8:  # High similarity
                pattern_id = similar_patterns[0][0].id
            else:
                # Create new pattern
                pattern = FailurePattern(
                    id="",  # Will be set by RAG system
                    job_name=failure_analysis.job_name,
                    failure_type=failure_analysis.failure_type,
                    error_signature=failure_analysis.root_cause[:200],
                    root_cause=failure_analysis.root_cause,
                    solution_applied=decision.fix_proposal.solution_description if decision.fix_proposal else "No solution applied",
                    success_rate=1.0 if action_result.success else 0.0,
                    occurrence_count=1,
                    last_seen=datetime.now(),
                    metadata={
                        'severity': failure_analysis.severity,
                        'affected_components': failure_analysis.affected_components
                    }
                )
                self.rag_system.add_failure_pattern(pattern)
                pattern_id = pattern.id
            
            # Record resolution
            resolution = ResolutionHistory(
                id="",  # Will be set by RAG system
                pattern_id=pattern_id,
                timestamp=datetime.now(),
                action_taken=decision.action.value,
                success=action_result.success,
                confidence=decision.confidence,
                fix_details={
                    'reasoning': decision.reasoning,
                    'security_risks': decision.security_risks,
                    'execution_time': action_result.execution_time
                }
            )
            
            self.rag_system.record_resolution(pattern_id, resolution)
            
            logger.info(f"Recorded outcome for pattern {pattern_id}")
            
        except Exception as e:
            logger.error(f"Failed to record outcome: {e}")
    
    async def _send_notification(self, incident_report: Dict[str, Any]):
        """Send notification about required human intervention"""
        
        try:
            # Check if Slack is configured
            slack_webhook = self.config.get('monitoring', {}).get('alert_channels', {}).get('slack', {}).get('webhook_url')
            if slack_webhook:
                import requests
                message = {
                    "text": f"🚨 Jenkins Failure Requires Human Intervention",
                    "attachments": [
                        {
                            "color": "danger" if incident_report['severity'] == 'critical' else "warning",
                            "fields": [
                                {"title": "Job", "value": incident_report['job_name'], "short": True},
                                {"title": "Build", "value": f"#{incident_report['build_number']}", "short": True},
                                {"title": "Failure Type", "value": incident_report['failure_type'], "short": True},
                                {"title": "Severity", "value": incident_report['severity'], "short": True},
                                {"title": "Root Cause", "value": incident_report['root_cause'][:200], "short": False}
                            ]
                        }
                    ]
                }
                requests.post(slack_webhook, json=message)
                logger.info("Slack notification sent")
            
        except Exception as e:
            logger.error(f"Failed to send notification: {e}")
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get decision engine statistics"""
        
        total_actions = len(self.action_history)
        if total_actions == 0:
            return {'total_actions': 0}
        
        action_counts = {}
        successful_actions = 0
        
        for action in self.action_history:
            action_type = action.action_taken.value
            action_counts[action_type] = action_counts.get(action_type, 0) + 1
            if action.success:
                successful_actions += 1
        
        return {
            'total_actions': total_actions,
            'success_rate': successful_actions / total_actions,
            'action_distribution': action_counts,
            'rag_statistics': self.rag_system.get_statistics()
        }