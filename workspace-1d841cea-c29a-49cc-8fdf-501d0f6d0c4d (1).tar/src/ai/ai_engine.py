"""
AI Reasoning Engine
Core AI processing using LangChain and Groq for failure analysis and resolution
"""

import os
import json
import asyncio
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from datetime import datetime
from loguru import logger

from langchain.llms import Groq
from langchain.prompts import PromptTemplate, ChatPromptTemplate
from langchain.chains import LLMChain, SequentialChain
from langchain.memory import ConversationBufferMemory
from langchain.schema import HumanMessage, AIMessage, SystemMessage

from groq import Groq as GroqClient


@dataclass
class FailureAnalysis:
    job_name: str
    build_number: int
    failure_type: str
    root_cause: str
    confidence: float
    severity: str
    affected_components: List[str]
    suggested_fixes: List[str]
    reasoning_trace: str
    error_patterns: List[str]
    requires_human_intervention: bool


@dataclass
class FixProposal:
    solution_description: str
    file_changes: List[Dict[str, Any]]
    commands_to_run: List[str]
    configuration_changes: Dict[str, Any]
    confidence: float
    estimated_success_rate: float
    risks: List[str]
    testing_required: bool


class AIEngine:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.groq_api_key = config['ai']['groq_api_key']
        self.model_name = config['ai'].get('model', 'llama3-70b-8192')
        self.temperature = config['ai'].get('temperature', 0.1)
        self.max_tokens = config['ai'].get('max_tokens', 4096)
        
        # Confidence thresholds
        self.auto_fix_threshold = config['ai']['confidence_threshold']['auto_fix']
        self.pr_threshold = config['ai']['confidence_threshold']['pr_creation']
        self.human_threshold = config['ai']['confidence_threshold']['human_intervention']
        
        # Initialize Groq client
        self.groq_client = GroqClient(api_key=self.groq_api_key)
        
        # Initialize LangChain components
        self.llm = Groq(
            groq_api_key=self.groq_api_key,
            model_name=self.model_name,
            temperature=self.temperature,
            max_tokens=self.max_tokens
        )
        
        # Initialize prompts
        self._setup_prompts()
        
        logger.info(f"AI Engine initialized with model: {self.model_name}")
    
    def _setup_prompts(self):
        """Setup LangChain prompts for different analysis tasks"""
        
        # Failure classification prompt
        self.failure_classifier_prompt = PromptTemplate(
            input_variables=["console_log", "job_name", "build_context"],
            template="""
You are an expert DevOps engineer analyzing Jenkins build failures.

Analyze the following build failure and provide a detailed classification:

Job Name: {job_name}
Build Context: {build_context}
Console Log:
{console_log}

Please provide a JSON response with the following structure:
{{
    "failure_type": "one of: [compilation, test_failure, dependency_issue, configuration_error, infrastructure_issue, security_issue, network_issue, environment_issue, unknown]",
    "severity": "one of: [critical, high, medium, low]",
    "root_cause": "detailed explanation of what went wrong",
    "affected_components": ["list of affected components"],
    "error_patterns": ["list of error patterns found"],
    "confidence": 0.0-1.0,
    "reasoning": "step-by-step reasoning process"
}}

Focus on identifying the specific type of failure and its root cause.
"""
        )
        
        # Fix generation prompt
        self.fix_generator_prompt = PromptTemplate(
            input_variables=["failure_analysis", "code_context", "environment_info"],
            template="""
You are an expert DevOps engineer tasked with generating a fix for a Jenkins build failure.

Failure Analysis:
{failure_analysis}

Code Context:
{code_context}

Environment Information:
{environment_info}

Based on the analysis above, generate a comprehensive fix proposal in JSON format:
{{
    "solution_description": "detailed description of the proposed solution",
    "file_changes": [
        {{
            "path": "path/to/file",
            "action": "update|create|delete",
            "content": "new file content if update/create",
            "commit_message": "descriptive commit message"
        }}
    ],
    "commands_to_run": ["list of commands to execute"],
    "configuration_changes": {{
        "jenkins_config": {{}},
        "environment_vars": {{}}
    }},
    "confidence": 0.0-1.0,
    "estimated_success_rate": 0.0-1.0,
    "risks": ["list of potential risks"],
    "testing_required": true/false
}}

Only suggest fixes that are safe and likely to resolve the issue. If the issue requires human expertise, set confidence below 0.6.
"""
        )
        
        # Self-healing assessment prompt
        self.assessment_prompt = PromptTemplate(
            input_variables=["failure_analysis", "fix_proposal", "historical_data"],
            template="""
You are an AI assistant determining whether a Jenkins failure can be automatically fixed.

Failure Analysis:
{failure_analysis}

Proposed Fix:
{fix_proposal}

Historical Data:
{historical_data}

Assess whether this issue can be safely auto-fixed. Respond with JSON:
{{
    "should_auto_fix": true/false,
    "confidence": 0.0-1.0,
    "risk_level": "low|medium|high",
    "requires_approval": true/false,
    "recommended_action": "auto_fix|create_pr|human_intervention",
    "justification": "detailed reasoning for the decision"
}}

Consider:
- Complexity of the fix
- Potential impact on other systems
- Historical success rates
- Risk of making things worse
"""
        )
    
    async def analyze_failure(self, jenkins_build) -> FailureAnalysis:
        """Analyze a Jenkins build failure using AI"""
        try:
            logger.info(f"Analyzing failure for {jenkins_build.job_name}#{jenkins_build.build_number}")
            
            # Prepare context
            console_log = self._prepare_console_log(jenkins_build.console_log)
            build_context = self._prepare_build_context(jenkins_build)
            
            # Classify failure using Groq
            classification_result = await self._classify_failure(
                console_log, jenkins_build.job_name, build_context
            )
            
            # Parse and validate result
            analysis_data = json.loads(classification_result)
            
            analysis = FailureAnalysis(
                job_name=jenkins_build.job_name,
                build_number=jenkins_build.build_number,
                failure_type=analysis_data.get('failure_type', 'unknown'),
                root_cause=analysis_data.get('root_cause', 'Unknown root cause'),
                confidence=analysis_data.get('confidence', 0.0),
                severity=analysis_data.get('severity', 'medium'),
                affected_components=analysis_data.get('affected_components', []),
                suggested_fixes=analysis_data.get('suggested_fixes', []),
                reasoning_trace=analysis_data.get('reasoning', ''),
                error_patterns=analysis_data.get('error_patterns', []),
                requires_human_intervention=analysis_data.get('confidence', 0.0) < self.human_threshold
            )
            
            logger.info(f"Analysis complete: {analysis.failure_type} (confidence: {analysis.confidence:.2%})")
            return analysis
            
        except Exception as e:
            logger.error(f"Error in failure analysis: {e}")
            # Return fallback analysis
            return FailureAnalysis(
                job_name=jenkins_build.job_name,
                build_number=jenkins_build.build_number,
                failure_type='unknown',
                root_cause=f'Analysis failed: {str(e)}',
                confidence=0.0,
                severity='medium',
                affected_components=[],
                suggested_fixes=[],
                reasoning_trace=f'Error during analysis: {str(e)}',
                error_patterns=[],
                requires_human_intervention=True
            )
    
    async def generate_fix(self, analysis: FailureAnalysis, 
                          jenkins_build, code_context: Dict[str, Any] = None) -> FixProposal:
        """Generate a fix proposal based on failure analysis"""
        try:
            logger.info(f"Generating fix for {analysis.failure_type}")
            
            # Prepare context
            failure_analysis_json = json.dumps({
                'failure_type': analysis.failure_type,
                'root_cause': analysis.root_cause,
                'severity': analysis.severity,
                'affected_components': analysis.affected_components,
                'error_patterns': analysis.error_patterns
            }, indent=2)
            
            code_context_str = json.dumps(code_context or {}, indent=2)
            environment_info = self._prepare_environment_info(jenkins_build)
            
            # Generate fix using Groq
            fix_result = await self._generate_fix_internal(
                failure_analysis_json, code_context_str, environment_info
            )
            
            # Parse and validate result
            fix_data = json.loads(fix_result)
            
            proposal = FixProposal(
                solution_description=fix_data.get('solution_description', ''),
                file_changes=fix_data.get('file_changes', []),
                commands_to_run=fix_data.get('commands_to_run', []),
                configuration_changes=fix_data.get('configuration_changes', {}),
                confidence=fix_data.get('confidence', 0.0),
                estimated_success_rate=fix_data.get('estimated_success_rate', 0.0),
                risks=fix_data.get('risks', []),
                testing_required=fix_data.get('testing_required', True)
            )
            
            logger.info(f"Fix generated with confidence: {proposal.confidence:.2%}")
            return proposal
            
        except Exception as e:
            logger.error(f"Error generating fix: {e}")
            # Return fallback proposal
            return FixProposal(
                solution_description=f'Fix generation failed: {str(e)}',
                file_changes=[],
                commands_to_run=[],
                configuration_changes={},
                confidence=0.0,
                estimated_success_rate=0.0,
                risks=['AI generation failed'],
                testing_required=True
            )
    
    async def assess_auto_fix_feasibility(self, analysis: FailureAnalysis,
                                         proposal: FixProposal,
                                         historical_data: List[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Assess whether a fix can be automatically applied"""
        try:
            logger.info("Assessing auto-fix feasibility")
            
            # Prepare assessment context
            analysis_json = json.dumps({
                'failure_type': analysis.failure_type,
                'root_cause': analysis.root_cause,
                'severity': analysis.severity,
                'confidence': analysis.confidence
            }, indent=2)
            
            proposal_json = json.dumps({
                'solution_description': proposal.solution_description,
                'file_changes_count': len(proposal.file_changes),
                'confidence': proposal.confidence,
                'risks': proposal.risks
            }, indent=2)
            
            historical_json = json.dumps(historical_data or [], indent=2)
            
            # Get assessment from AI
            assessment_result = await self._assess_fix_internal(
                analysis_json, proposal_json, historical_json
            )
            
            assessment = json.loads(assessment_result)
            
            # Determine final action based on confidence thresholds
            confidence = assessment.get('confidence', 0.0)
            recommended_action = assessment.get('recommended_action', 'human_intervention')
            
            # Override based on our thresholds if needed
            if confidence >= self.auto_fix_threshold and recommended_action == 'auto_fix':
                final_action = 'auto_fix'
            elif confidence >= self.pr_threshold:
                final_action = 'create_pr'
            else:
                final_action = 'human_intervention'
            
            assessment['final_action'] = final_action
            
            logger.info(f"Auto-fix assessment: {final_action} (confidence: {confidence:.2%})")
            return assessment
            
        except Exception as e:
            logger.error(f"Error in auto-fix assessment: {e}")
            return {
                'should_auto_fix': False,
                'confidence': 0.0,
                'risk_level': 'high',
                'requires_approval': True,
                'recommended_action': 'human_intervention',
                'final_action': 'human_intervention',
                'justification': f'Assessment failed: {str(e)}'
            }
    
    async def _classify_failure(self, console_log: str, job_name: str, 
                               build_context: str) -> str:
        """Classify failure type using Groq API"""
        try:
            chat_completion = self.groq_client.chat.completions.create(
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert DevOps engineer analyzing Jenkins build failures. Always respond with valid JSON."
                    },
                    {
                        "role": "user",
                        "content": self.failure_classifier_prompt.format(
                            console_log=console_log,
                            job_name=job_name,
                            build_context=build_context
                        )
                    }
                ],
                model=self.model_name,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                response_format={"type": "json_object"}
            )
            
            return chat_completion.choices[0].message.content
            
        except Exception as e:
            logger.error(f"Error in failure classification: {e}")
            raise
    
    async def _generate_fix_internal(self, failure_analysis: str, code_context: str,
                                   environment_info: str) -> str:
        """Generate fix using Groq API"""
        try:
            chat_completion = self.groq_client.chat.completions.create(
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert DevOps engineer generating fixes for Jenkins failures. Always respond with valid JSON."
                    },
                    {
                        "role": "user",
                        "content": self.fix_generator_prompt.format(
                            failure_analysis=failure_analysis,
                            code_context=code_context,
                            environment_info=environment_info
                        )
                    }
                ],
                model=self.model_name,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                response_format={"type": "json_object"}
            )
            
            return chat_completion.choices[0].message.content
            
        except Exception as e:
            logger.error(f"Error in fix generation: {e}")
            raise
    
    async def _assess_fix_internal(self, failure_analysis: str, fix_proposal: str,
                                 historical_data: str) -> str:
        """Assess fix feasibility using Groq API"""
        try:
            chat_completion = self.groq_client.chat.completions.create(
                messages=[
                    {
                        "role": "system",
                        "content": "You are an AI assistant assessing whether fixes can be automatically applied. Always respond with valid JSON."
                    },
                    {
                        "role": "user",
                        "content": self.assessment_prompt.format(
                            failure_analysis=failure_analysis,
                            fix_proposal=fix_proposal,
                            historical_data=historical_data
                        )
                    }
                ],
                model=self.model_name,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                response_format={"type": "json_object"}
            )
            
            return chat_completion.choices[0].message.content
            
        except Exception as e:
            logger.error(f"Error in fix assessment: {e}")
            raise
    
    def _prepare_console_log(self, console_log: str) -> str:
        """Prepare console log for analysis"""
        # Truncate if too long
        max_length = 10000
        if len(console_log) > max_length:
            # Keep the beginning and end, truncate middle
            start = console_log[:max_length//2]
            end = console_log[-max_length//2:]
            return f"{start}\n\n... [LOG TRUNCATED] ...\n\n{end}"
        return console_log
    
    def _prepare_build_context(self, jenkins_build) -> str:
        """Prepare build context information"""
        context = {
            'job_name': jenkins_build.job_name,
            'build_number': jenkins_build.build_number,
            'status': jenkins_build.status,
            'duration': jenkins_build.duration,
            'timestamp': jenkins_build.timestamp.isoformat(),
            'git_commit': jenkins_build.git_commit,
            'git_branch': jenkins_build.git_branch,
            'test_results': jenkins_build.test_results,
            'artifacts_count': len(jenkins_build.artifacts)
        }
        return json.dumps(context, indent=2)
    
    def _prepare_environment_info(self, jenkins_build) -> str:
        """Prepare environment information"""
        env_info = {
            'environment_vars': jenkins_build.environment_vars,
            'job_name': jenkins_build.job_name,
            'build_number': jenkins_build.build_number
        }
        return json.dumps(env_info, indent=2)