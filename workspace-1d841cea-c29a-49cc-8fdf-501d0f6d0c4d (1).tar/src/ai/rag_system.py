"""
RAG System with LlamaIndex
Retrieval-Augmented Generation for failure pattern recognition and learning
"""

import os
import json
import pickle
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from pathlib import Path

from llama_index.core import VectorStoreIndex, Document, ServiceContext
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.storage import StorageContext
from llama_index.core.vector_stores import SimpleVectorStore
from llama_index.embeddings import HuggingFaceEmbedding
from llama_index.llms import OpenAI

import faiss
import numpy as np
from sentence_transformers import SentenceTransformer
from loguru import logger


@dataclass
class FailurePattern:
    id: str
    job_name: str
    failure_type: str
    error_signature: str
    root_cause: str
    solution_applied: str
    success_rate: float
    occurrence_count: int
    last_seen: datetime
    embedding: Optional[np.ndarray] = None
    metadata: Dict[str, Any] = None


@dataclass
class ResolutionHistory:
    id: str
    pattern_id: str
    timestamp: datetime
    action_taken: str  # 'auto_fix', 'pr_created', 'human_intervention'
    success: bool
    confidence: float
    human_feedback: Optional[str] = None
    pr_url: Optional[str] = None
    fix_details: Dict[str, Any] = None


class RAGSystem:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.vector_db_type = config['vector_db']['type']
        self.vector_db_path = Path(config['vector_db']['path'])
        self.embedding_model_name = config['vector_db']['embedding_model']
        self.dimension = config['vector_db']['dimension']
        
        # Create directories
        self.vector_db_path.mkdir(parents=True, exist_ok=True)
        self.patterns_path = self.vector_db_path / "patterns"
        self.patterns_path.mkdir(exist_ok=True)
        
        # Initialize embedding model
        self.embedding_model = SentenceTransformer(self.embedding_model_name)
        
        # Initialize vector store
        self._init_vector_store()
        
        # Initialize LlamaIndex components
        self._init_llama_index()
        
        # Load existing patterns
        self.failure_patterns = self._load_patterns()
        self.resolution_history = self._load_resolution_history()
        
        logger.info(f"RAG System initialized with {len(self.failure_patterns)} patterns")
    
    def _init_vector_store(self):
        """Initialize vector store based on configuration"""
        if self.vector_db_type == 'faiss':
            self.faiss_index = faiss.IndexFlatIP(self.dimension)
            self.pattern_embeddings = []
            self.pattern_ids = []
        elif self.vector_db_type == 'chroma':
            # Initialize ChromaDB (placeholder)
            pass
        else:
            raise ValueError(f"Unsupported vector store type: {self.vector_db_type}")
    
    def _init_llama_index(self):
        """Initialize LlamaIndex components"""
        try:
            # Initialize embedding model for LlamaIndex
            embed_model = HuggingFaceEmbedding(model_name=self.embedding_model_name)
            
            # Initialize service context
            self.service_context = ServiceContext.from_defaults(
                embed_model=embed_model,
                llm=None,  # We'll use our own Groq-based LLM
                node_parser=SentenceSplitter(chunk_size=1024, chunk_overlap=20)
            )
            
            # Initialize vector store for LlamaIndex
            vector_store = SimpleVectorStore()
            storage_context = StorageContext.from_defaults(vector_store=vector_store)
            
            # Create empty index
            self.llama_index = VectorStoreIndex.from_documents(
                [], storage_context=storage_context, service_context=self.service_context
            )
            
            logger.info("LlamaIndex components initialized")
            
        except Exception as e:
            logger.warning(f"Failed to initialize LlamaIndex: {e}")
            self.llama_index = None
    
    def add_failure_pattern(self, pattern: FailurePattern) -> bool:
        """Add a new failure pattern to the knowledge base"""
        try:
            # Generate embedding
            text_to_embed = self._create_pattern_text(pattern)
            embedding = self.embedding_model.encode(text_to_embed)
            pattern.embedding = embedding
            
            # Add to vector store
            if self.vector_db_type == 'faiss':
                pattern_id = len(self.pattern_ids)
                self.faiss_index.add(np.array([embedding]).astype('float32'))
                self.pattern_embeddings.append(embedding)
                self.pattern_ids.append(pattern_id)
                pattern.id = str(pattern_id)
            
            # Store pattern metadata
            pattern_file = self.patterns_path / f"{pattern.id}.json"
            with open(pattern_file, 'w') as f:
                pattern_data = asdict(pattern)
                pattern_data['embedding'] = None  # Don't store embedding in JSON
                pattern_data['last_seen'] = pattern.last_seen.isoformat()
                json.dump(pattern_data, f, indent=2)
            
            # Add to in-memory patterns
            self.failure_patterns[pattern.id] = pattern
            
            # Update LlamaIndex if available
            if self.llama_index:
                doc = Document(text=text_to_embed, metadata=asdict(pattern))
                self.llama_index.insert(doc)
            
            logger.info(f"Added failure pattern: {pattern.id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to add failure pattern: {e}")
            return False
    
    def search_similar_patterns(self, query_text: str, top_k: int = 5) -> List[Tuple[FailurePattern, float]]:
        """Search for similar failure patterns"""
        try:
            # Generate query embedding
            query_embedding = self.embedding_model.encode(query_text)
            
            if self.vector_db_type == 'faiss' and len(self.pattern_embeddings) > 0:
                # Search in FAISS
                query_embedding = query_embedding.reshape(1, -1).astype('float32')
                scores, indices = self.faiss_index.search(query_embedding, min(top_k, len(self.pattern_ids)))
                
                results = []
                for score, idx in zip(scores[0], indices[0]):
                    if idx >= 0 and idx < len(self.pattern_ids):
                        pattern_id = str(self.pattern_ids[idx])
                        if pattern_id in self.failure_patterns:
                            pattern = self.failure_patterns[pattern_id]
                            results.append((pattern, float(score)))
                
                return sorted(results, key=lambda x: x[1], reverse=True)
            
            # Fallback to LlamaIndex search
            if self.llama_index:
                query_engine = self.llama_index.as_query_engine()
                response = query_engine.query(query_text)
                # Parse response to get patterns (implementation depends on response format)
            
            return []
            
        except Exception as e:
            logger.error(f"Error searching similar patterns: {e}")
            return []
    
    def get_resolution_suggestions(self, failure_analysis: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Get resolution suggestions based on similar patterns"""
        try:
            # Create query text from failure analysis
            query_text = self._create_query_from_analysis(failure_analysis)
            
            # Search for similar patterns
            similar_patterns = self.search_similar_patterns(query_text, top_k=3)
            
            suggestions = []
            for pattern, similarity_score in similar_patterns:
                # Get resolution history for this pattern
                pattern_history = [h for h in self.resolution_history.values() 
                                 if h.pattern_id == pattern.id and h.success]
                
                if pattern_history:
                    # Calculate success metrics
                    success_rate = len([h for h in pattern_history if h.success]) / len(pattern_history)
                    avg_confidence = np.mean([h.confidence for h in pattern_history])
                    
                    suggestion = {
                        'pattern_id': pattern.id,
                        'similarity_score': similarity_score,
                        'failure_type': pattern.failure_type,
                        'root_cause': pattern.root_cause,
                        'recommended_solution': pattern.solution_applied,
                        'historical_success_rate': success_rate,
                        'historical_confidence': avg_confidence,
                        'occurrence_count': pattern.occurrence_count,
                        'last_seen': pattern.last_seen.isoformat(),
                        'applicable_actions': self._get_applicable_actions(pattern_history)
                    }
                    suggestions.append(suggestion)
            
            return sorted(suggestions, key=lambda x: x['similarity_score'], reverse=True)
            
        except Exception as e:
            logger.error(f"Error getting resolution suggestions: {e}")
            return []
    
    def record_resolution(self, pattern_id: str, resolution: ResolutionHistory) -> bool:
        """Record a resolution attempt and its outcome"""
        try:
            resolution.pattern_id = pattern_id
            resolution.id = f"{pattern_id}_{datetime.now().timestamp()}"
            
            # Store resolution
            resolution_file = self.patterns_path / f"resolutions_{resolution.id}.json"
            with open(resolution_file, 'w') as f:
                resolution_data = asdict(resolution)
                resolution_data['timestamp'] = resolution.timestamp.isoformat()
                json.dump(resolution_data, f, indent=2)
            
            # Update in-memory history
            self.resolution_history[resolution.id] = resolution
            
            # Update pattern statistics
            if pattern_id in self.failure_patterns:
                pattern = self.failure_patterns[pattern_id]
                pattern.occurrence_count += 1
                pattern.last_seen = resolution.timestamp
                
                # Update success rate
                pattern_resolutions = [h for h in self.resolution_history.values() 
                                     if h.pattern_id == pattern_id]
                if pattern_resolutions:
                    successful_resolutions = len([h for h in pattern_resolutions if h.success])
                    pattern.success_rate = successful_resolutions / len(pattern_resolutions)
                
                # Save updated pattern
                self._save_pattern(pattern)
            
            logger.info(f"Recorded resolution: {resolution.id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to record resolution: {e}")
            return False
    
    def learn_from_feedback(self, resolution_id: str, human_feedback: str, 
                          success: bool) -> bool:
        """Learn from human feedback to improve future recommendations"""
        try:
            if resolution_id not in self.resolution_history:
                logger.warning(f"Resolution {resolution_id} not found")
                return False
            
            resolution = self.resolution_history[resolution_id]
            resolution.human_feedback = human_feedback
            resolution.success = success
            
            # Update resolution file
            resolution_file = self.patterns_path / f"resolutions_{resolution_id}.json"
            with open(resolution_file, 'w') as f:
                resolution_data = asdict(resolution)
                resolution_data['timestamp'] = resolution.timestamp.isoformat()
                json.dump(resolution_data, f, indent=2)
            
            # If this was successful, we might want to boost this pattern's weight
            if success and resolution.pattern_id in self.failure_patterns:
                pattern = self.failure_patterns[resolution.pattern_id]
                # Potentially update pattern based on feedback
                logger.info(f"Updated pattern {resolution.pattern_id} based on feedback")
            
            logger.info(f"Learned from feedback for resolution {resolution_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to learn from feedback: {e}")
            return False
    
    def _create_pattern_text(self, pattern: FailurePattern) -> str:
        """Create searchable text from pattern"""
        return f"""
        Job: {pattern.job_name}
        Failure Type: {pattern.failure_type}
        Error Signature: {pattern.error_signature}
        Root Cause: {pattern.root_cause}
        Solution Applied: {pattern.solution_applied}
        Success Rate: {pattern.success_rate}
        Occurrences: {pattern.occurrence_count}
        """
    
    def _create_query_from_analysis(self, analysis: Dict[str, Any]) -> str:
        """Create query text from failure analysis"""
        return f"""
        Job: {analysis.get('job_name', 'Unknown')}
        Failure Type: {analysis.get('failure_type', 'Unknown')}
        Root Cause: {analysis.get('root_cause', 'Unknown')}
        Error Patterns: {', '.join(analysis.get('error_patterns', []))}
        Affected Components: {', '.join(analysis.get('affected_components', []))}
        """
    
    def _get_applicable_actions(self, pattern_history: List[ResolutionHistory]) -> List[str]:
        """Get applicable actions based on pattern history"""
        actions = set()
        for resolution in pattern_history:
            actions.add(resolution.action_taken)
        return list(actions)
    
    def _load_patterns(self) -> Dict[str, FailurePattern]:
        """Load existing failure patterns"""
        patterns = {}
        try:
            for pattern_file in self.patterns_path.glob("*.json"):
                if not pattern_file.name.startswith("resolutions_"):
                    with open(pattern_file, 'r') as f:
                        pattern_data = json.load(f)
                        pattern_data['last_seen'] = datetime.fromisoformat(pattern_data['last_seen'])
                        pattern = FailurePattern(**pattern_data)
                        patterns[pattern.id] = pattern
                        
                        # Rebuild vector store
                        if pattern.embedding is not None:
                            if self.vector_db_type == 'faiss':
                                pattern_id = len(self.pattern_ids)
                                self.faiss_index.add(np.array([pattern.embedding]).astype('float32'))
                                self.pattern_embeddings.append(pattern.embedding)
                                self.pattern_ids.append(pattern_id)
            
            logger.info(f"Loaded {len(patterns)} failure patterns")
            
        except Exception as e:
            logger.error(f"Error loading patterns: {e}")
        
        return patterns
    
    def _load_resolution_history(self) -> Dict[str, ResolutionHistory]:
        """Load resolution history"""
        history = {}
        try:
            for resolution_file in self.patterns_path.glob("resolutions_*.json"):
                with open(resolution_file, 'r') as f:
                    resolution_data = json.load(f)
                    resolution_data['timestamp'] = datetime.fromisoformat(resolution_data['timestamp'])
                    resolution = ResolutionHistory(**resolution_data)
                    history[resolution.id] = resolution
            
            logger.info(f"Loaded {len(history)} resolution records")
            
        except Exception as e:
            logger.error(f"Error loading resolution history: {e}")
        
        return history
    
    def _save_pattern(self, pattern: FailurePattern):
        """Save pattern to disk"""
        try:
            pattern_file = self.patterns_path / f"{pattern.id}.json"
            with open(pattern_file, 'w') as f:
                pattern_data = asdict(pattern)
                pattern_data['embedding'] = None
                pattern_data['last_seen'] = pattern.last_seen.isoformat()
                json.dump(pattern_data, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save pattern {pattern.id}: {e}")
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get RAG system statistics"""
        total_patterns = len(self.failure_patterns)
        total_resolutions = len(self.resolution_history)
        
        if total_resolutions > 0:
            successful_resolutions = len([r for r in self.resolution_history.values() if r.success])
            success_rate = successful_resolutions / total_resolutions
        else:
            success_rate = 0.0
        
        # Pattern distribution by type
        pattern_types = {}
        for pattern in self.failure_patterns.values():
            pattern_types[pattern.failure_type] = pattern_types.get(pattern.failure_type, 0) + 1
        
        return {
            'total_patterns': total_patterns,
            'total_resolutions': total_resolutions,
            'overall_success_rate': success_rate,
            'pattern_distribution': pattern_types,
            'vector_store_type': self.vector_db_type,
            'embedding_model': self.embedding_model_name
        }