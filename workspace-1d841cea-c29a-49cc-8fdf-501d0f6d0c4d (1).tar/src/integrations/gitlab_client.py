"""
GitLab Integration Layer
Handles GitLab API operations for PR creation and management
"""

import gitlab
import requests
import json
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime
from dataclasses import dataclass
from loguru import logger
import base64
import difflib


@dataclass
class GitLabPR:
    id: int
    iid: int
    title: str
    description: str
    source_branch: str
    target_branch: str
    author: str
    created_at: datetime
    status: str
    web_url: str
    changes: Dict[str, Any]


@dataclass
class GitLabFile:
    path: str
    content: str
    encoding: str = 'base64'


class GitLabClient:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.gitlab_url = config['gitlab']['url']
        self.token = config['gitlab']['token']
        self.default_branch = config['gitlab'].get('default_branch', 'main')
        self.require_approval = config['gitlab'].get('require_approval', True)
        
        # Initialize GitLab client
        self.client = gitlab.Gitlab(self.gitlab_url, private_token=self.token)
        
        logger.info(f"Connected to GitLab at {self.gitlab_url}")
    
    def test_connection(self) -> bool:
        """Test connection to GitLab server"""
        try:
            user = self.client.auth()
            logger.info(f"Successfully connected to GitLab as user: {user.username}")
            return True
        except Exception as e:
            logger.error(f"Failed to connect to GitLab: {e}")
            return False
    
    def get_project(self, project_id: str) -> Optional[Any]:
        """Get GitLab project by ID or path"""
        try:
            project = self.client.projects.get(project_id)
            return project
        except Exception as e:
            logger.error(f"Failed to get project {project_id}: {e}")
            return None
    
    def create_branch(self, project_id: str, branch_name: str, source_branch: str = None) -> bool:
        """Create a new branch in the project"""
        try:
            project = self.get_project(project_id)
            if not project:
                return False
            
            source = source_branch or self.default_branch
            project.branches.create({
                'branch': branch_name,
                'ref': source
            })
            
            logger.info(f"Created branch {branch_name} from {source}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to create branch {branch_name}: {e}")
            return False
    
    def get_file_content(self, project_id: str, file_path: str, ref: str = 'main') -> Optional[str]:
        """Get file content from repository"""
        try:
            project = self.get_project(project_id)
            if not project:
                return None
            
            file = project.files.get(file_path=file_path, ref=ref)
            content = base64.b64decode(file.content).decode('utf-8')
            return content
            
        except Exception as e:
            logger.error(f"Failed to get file {file_path}: {e}")
            return None
    
    def update_file(self, project_id: str, file_path: str, content: str, 
                   branch: str, commit_message: str) -> bool:
        """Update file in repository"""
        try:
            project = self.get_project(project_id)
            if not project:
                return False
            
            # Get current file to ensure we're updating the right version
            try:
                current_file = project.files.get(file_path=file_path, ref=branch)
                current_content = base64.b64decode(current_file.content).decode('utf-8')
            except:
                current_content = ""
            
            # Create commit
            project.files.create({
                'file_path': file_path,
                'content': content,
                'branch': branch,
                'commit_message': commit_message,
                'encoding': 'text'
            })
            
            logger.info(f"Updated file {file_path} in branch {branch}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to update file {file_path}: {e}")
            return False
    
    def create_file(self, project_id: str, file_path: str, content: str,
                   branch: str, commit_message: str) -> bool:
        """Create new file in repository"""
        try:
            project = self.get_project(project_id)
            if not project:
                return False
            
            project.files.create({
                'file_path': file_path,
                'content': content,
                'branch': branch,
                'commit_message': commit_message,
                'encoding': 'text'
            })
            
            logger.info(f"Created file {file_path} in branch {branch}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to create file {file_path}: {e}")
            return False
    
    def create_merge_request(self, project_id: str, title: str, description: str,
                           source_branch: str, target_branch: str = None,
                           labels: List[str] = None) -> Optional[GitLabPR]:
        """Create a merge request (pull request)"""
        try:
            project = self.get_project(project_id)
            if not project:
                return None
            
            target = target_branch or self.default_branch
            
            mr = project.mergerequests.create({
                'title': title,
                'description': description,
                'source_branch': source_branch,
                'target_branch': target,
                'labels': labels or [],
                'remove_source_branch': True
            })
            
            # Get detailed MR info
            mr_info = project.mergerequests.get(mr.iid)
            
            gitlab_pr = GitLabPR(
                id=mr_info.id,
                iid=mr_info.iid,
                title=mr_info.title,
                description=mr_info.description,
                source_branch=mr_info.source_branch,
                target_branch=mr_info.target_branch,
                author=mr_info.author['name'],
                created_at=datetime.fromisoformat(mr_info.created_at.replace('Z', '+00:00')),
                status=mr_info.state,
                web_url=mr_info.web_url,
                changes={}
            )
            
            logger.info(f"Created merge request: {gitlab_pr.web_url}")
            return gitlab_pr
            
        except Exception as e:
            logger.error(f"Failed to create merge request: {e}")
            return None
    
    def get_merge_request_changes(self, project_id: str, mr_iid: int) -> Optional[Dict[str, Any]]:
        """Get changes for a merge request"""
        try:
            project = self.get_project(project_id)
            if not project:
                return None
            
            mr = project.mergerequests.get(mr_iid)
            changes = mr.changes()
            
            return changes
            
        except Exception as e:
            logger.error(f"Failed to get MR changes: {e}")
            return None
    
    def add_comment_to_mr(self, project_id: str, mr_iid: int, comment: str) -> bool:
        """Add comment to merge request"""
        try:
            project = self.get_project(project_id)
            if not project:
                return False
            
            mr = project.mergerequests.get(mr_iid)
            mr.notes.create({'body': comment})
            
            logger.info(f"Added comment to MR {mr_iid}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to add comment to MR {mr_iid}: {e}")
            return False
    
    def merge_merge_request(self, project_id: str, mr_iid: int, 
                          merge_message: str = None) -> bool:
        """Merge a merge request"""
        try:
            project = self.get_project(project_id)
            if not project:
                return False
            
            mr = project.mergerequests.get(mr_iid)
            
            # Check if MR can be merged
            if mr.merge_status != 'can_be_merged':
                logger.warning(f"MR {mr_iid} cannot be merged. Status: {mr.merge_status}")
                return False
            
            mr.merge(merge_message=merge_message)
            logger.info(f"Merged MR {mr_iid}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to merge MR {mr_iid}: {e}")
            return False
    
    def create_fix_pr(self, project_id: str, issue_analysis: Dict[str, Any],
                     proposed_fix: Dict[str, Any]) -> Optional[GitLabPR]:
        """Create a comprehensive fix PR based on AI analysis"""
        
        # Generate branch name
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        branch_name = f"fix/ai-auto-fix-{timestamp}"
        
        # Create branch
        if not self.create_branch(project_id, branch_name):
            return None
        
        # Apply file changes
        changes_applied = []
        for file_change in proposed_fix.get('file_changes', []):
            file_path = file_change['path']
            action = file_change['action']  # 'update', 'create', 'delete'
            
            if action == 'update':
                success = self.update_file(
                    project_id, file_path, file_change['content'],
                    branch_name, file_change['commit_message']
                )
            elif action == 'create':
                success = self.create_file(
                    project_id, file_path, file_change['content'],
                    branch_name, file_change['commit_message']
                )
            else:
                success = True  # Delete action handled differently
            
            if success:
                changes_applied.append(file_path)
        
        if not changes_applied:
            logger.warning("No changes were applied")
            return None
        
        # Generate PR title and description
        title = f"🤖 AI Auto-Fix: {issue_analysis.get('failure_type', 'Unknown Issue')}"
        
        description = self._generate_pr_description(issue_analysis, proposed_fix, changes_applied)
        
        # Create PR
        labels = ['ai-generated', 'auto-fix', issue_analysis.get('failure_type', 'unknown')]
        pr = self.create_merge_request(
            project_id, title, description, branch_name, labels=labels
        )
        
        return pr
    
    def _generate_pr_description(self, issue_analysis: Dict[str, Any],
                               proposed_fix: Dict[str, Any], changes_applied: List[str]) -> str:
        """Generate comprehensive PR description"""
        
        description = f"""## 🤖 AI-Generated Fix

### 📋 Issue Summary
- **Job**: {issue_analysis.get('job_name', 'Unknown')}
- **Build**: #{issue_analysis.get('build_number', 'Unknown')}
- **Failure Type**: {issue_analysis.get('failure_type', 'Unknown')}
- **Confidence**: {issue_analysis.get('confidence', 0):.2%}

### 🔍 Root Cause Analysis
{issue_analysis.get('root_cause', 'No root cause analysis available')}

### 🛠️ Proposed Solution
{proposed_fix.get('solution_description', 'No solution description available')}

### 📁 Files Modified
"""
        
        for file_path in changes_applied:
            description += f"- `{file_path}`\n"
        
        description += f"""
### 🧠 AI Reasoning
{issue_analysis.get('reasoning_trace', 'No reasoning trace available')}

### ⚠️ Review Required
This PR was automatically generated by an AI system. Please review:
1. The proposed changes fix the identified issue
2. No unintended side effects are introduced
3. All tests pass after applying the fix

### 📊 Additional Context
- **Original Error**: {issue_analysis.get('error_message', 'N/A')}
- **Git Commit**: {issue_analysis.get('git_commit', 'N/A')}
- **Analysis Timestamp**: {datetime.now().isoformat()}

---
*Generated by AI DevOps Framework*
"""
        
        return description
    
    def get_pr_status(self, project_id: str, mr_iid: int) -> Optional[Dict[str, Any]]:
        """Get current status of a merge request"""
        try:
            project = self.get_project(project_id)
            if not project:
                return None
            
            mr = project.mergerequests.get(mr_iid)
            
            return {
                'iid': mr.iid,
                'title': mr.title,
                'state': mr.state,
                'merge_status': mr.merge_status,
                'author': mr.author['name'],
                'created_at': mr.created_at,
                'updated_at': mr.updated_at,
                'web_url': mr.web_url,
                'approvals_required': self.require_approval,
                'approved': len(mr.approvals.get('approved_by', [])) > 0 if self.require_approval else True
            }
            
        except Exception as e:
            logger.error(f"Failed to get PR status: {e}")
            return None