"""
Jenkins Integration Layer
Handles communication with Jenkins API for monitoring and data collection
"""

import jenkins
import requests
import json
import asyncio
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from dataclasses import dataclass
from loguru import logger
import yaml


@dataclass
class JenkinsJob:
    name: str
    url: str
    build_number: int
    status: str
    timestamp: datetime
    duration: int
    cause: str
    parameters: Dict[str, Any]


@dataclass
class JenkinsBuild:
    job_name: str
    build_number: int
    status: str
    timestamp: datetime
    duration: int
    console_log: str
    test_results: Optional[Dict[str, Any]]
    artifacts: List[Dict[str, Any]]
    environment_vars: Dict[str, str]
    git_commit: Optional[str]
    git_branch: Optional[str]


class JenkinsClient:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.server_url = config['jenkins']['url']
        self.username = config['jenkins']['username']
        self.api_token = config['jenkins']['api_token']
        self.poll_interval = config['jenkins'].get('poll_interval', 30)
        self.max_retries = config['jenkins'].get('max_retries', 3)
        self.timeout = config['jenkins'].get('timeout', 300)
        
        # Initialize Jenkins client
        self.client = jenkins.Jenkins(
            self.server_url,
            username=self.username,
            password=self.api_token,
            timeout=self.timeout
        )
        
        logger.info(f"Connected to Jenkins at {self.server_url}")
    
    def test_connection(self) -> bool:
        """Test connection to Jenkins server"""
        try:
            version = self.client.get_version()
            logger.info(f"Successfully connected to Jenkins version: {version}")
            return True
        except Exception as e:
            logger.error(f"Failed to connect to Jenkins: {e}")
            return False
    
    def get_all_jobs(self) -> List[JenkinsJob]:
        """Get all Jenkins jobs with their latest build information"""
        try:
            jobs_info = self.client.get_jobs()
            jobs = []
            
            for job_info in jobs_info:
                job_name = job_info['name']
                job_url = job_info['url']
                
                try:
                    # Get latest build info
                    last_build = self.client.get_job_info(job_name)['lastBuild']
                    if last_build:
                        build_number = last_build['number']
                        build_info = self.client.get_build_info(job_name, build_number)
                        
                        job = JenkinsJob(
                            name=job_name,
                            url=job_url,
                            build_number=build_number,
                            status=build_info['result'] or 'PENDING',
                            timestamp=datetime.fromtimestamp(build_info['timestamp'] / 1000),
                            duration=build_info['duration'],
                            cause=self._extract_cause(build_info),
                            parameters=self._extract_parameters(build_info)
                        )
                        jobs.append(job)
                except Exception as e:
                    logger.warning(f"Failed to get build info for job {job_name}: {e}")
                    continue
            
            return jobs
        except Exception as e:
            logger.error(f"Failed to get jobs: {e}")
            return []
    
    def get_failed_jobs(self, since_hours: int = 24) -> List[JenkinsJob]:
        """Get jobs that have failed in the specified time window"""
        all_jobs = self.get_all_jobs()
        cutoff_time = datetime.now() - timedelta(hours=since_hours)
        
        failed_jobs = [
            job for job in all_jobs 
            if job.status in ['FAILURE', 'ABORTED', 'UNSTABLE'] 
            and job.timestamp > cutoff_time
        ]
        
        logger.info(f"Found {len(failed_jobs)} failed jobs in the last {since_hours} hours")
        return failed_jobs
    
    def get_build_details(self, job_name: str, build_number: int) -> Optional[JenkinsBuild]:
        """Get detailed information about a specific build"""
        try:
            build_info = self.client.get_build_info(job_name, build_number)
            console_log = self.client.get_build_console_output(job_name, build_number)
            
            # Get test results if available
            test_results = None
            try:
                test_report = self.client.get_test_results(job_name, build_number)
                test_results = {
                    'total': test_report.get('failCount', 0) + test_report.get('passCount', 0),
                    'failed': test_report.get('failCount', 0),
                    'passed': test_report.get('passCount', 0),
                    'skipped': test_report.get('skipCount', 0)
                }
            except Exception:
                logger.debug(f"No test results found for {job_name}#{build_number}")
            
            # Get artifacts
            artifacts = []
            try:
                artifact_list = self.client.get_build_artifacts(job_name, build_number)
                artifacts = [
                    {
                        'name': artifact['fileName'],
                        'path': artifact['relativePath'],
                        'size': artifact.get('size', 0)
                    }
                    for artifact in artifact_list
                ]
            except Exception:
                logger.debug(f"No artifacts found for {job_name}#{build_number}")
            
            # Extract git information
            git_commit = None
            git_branch = None
            try:
                actions = build_info.get('actions', [])
                for action in actions:
                    if 'lastBuiltRevision' in action:
                        git_commit = action['lastBuiltRevision'].get('SHA1')
                        git_branch = action['lastBuiltRevision'].get('branch', [{}])[0].get('name')
                        break
            except Exception:
                logger.debug(f"No git information found for {job_name}#{build_number}")
            
            # Get environment variables
            environment_vars = {}
            try:
                # This might require additional plugins or permissions
                env_vars = self.client.get_build_env_vars(job_name, build_number)
                environment_vars = env_vars or {}
            except Exception:
                logger.debug(f"Could not retrieve environment variables for {job_name}#{build_number}")
            
            build = JenkinsBuild(
                job_name=job_name,
                build_number=build_number,
                status=build_info['result'] or 'PENDING',
                timestamp=datetime.fromtimestamp(build_info['timestamp'] / 1000),
                duration=build_info['duration'],
                console_log=console_log,
                test_results=test_results,
                artifacts=artifacts,
                environment_vars=environment_vars,
                git_commit=git_commit,
                git_branch=git_branch
            )
            
            return build
            
        except Exception as e:
            logger.error(f"Failed to get build details for {job_name}#{build_number}: {e}")
            return None
    
    def trigger_build(self, job_name: str, parameters: Optional[Dict[str, Any]] = None) -> bool:
        """Trigger a new build for a job"""
        try:
            if parameters:
                self.client.build_job(job_name, parameters)
            else:
                self.client.build_job(job_name)
            
            logger.info(f"Successfully triggered build for job: {job_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to trigger build for {job_name}: {e}")
            return False
    
    def get_job_config(self, job_name: str) -> Optional[str]:
        """Get Jenkins job configuration XML"""
        try:
            config_xml = self.client.get_job_config(job_name)
            return config_xml
        except Exception as e:
            logger.error(f"Failed to get config for job {job_name}: {e}")
            return None
    
    def update_job_config(self, job_name: str, config_xml: str) -> bool:
        """Update Jenkins job configuration"""
        try:
            self.client.reconfig_job(job_name, config_xml)
            logger.info(f"Successfully updated config for job: {job_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to update config for job {job_name}: {e}")
            return False
    
    def _extract_cause(self, build_info: Dict[str, Any]) -> str:
        """Extract build cause from build info"""
        try:
            actions = build_info.get('actions', [])
            for action in actions:
                if 'causes' in action:
                    causes = action['causes']
                    if causes:
                        cause = causes[0]
                        if 'userId' in cause:
                            return f"Triggered by user: {cause['userId']}"
                        elif 'upstreamProject' in cause:
                            return f"Triggered by upstream: {cause['upstreamProject']}"
                        else:
                            return cause.get('shortDescription', 'Unknown cause')
            return 'Unknown cause'
        except Exception:
            return 'Unknown cause'
    
    def _extract_parameters(self, build_info: Dict[str, Any]) -> Dict[str, Any]:
        """Extract build parameters from build info"""
        try:
            actions = build_info.get('actions', [])
            for action in actions:
                if 'parameters' in action:
                    return {
                        param['name']: param.get('value', '')
                        for param in action['parameters']
                    }
            return {}
        except Exception:
            return {}
    
    async def monitor_jobs(self, callback) -> None:
        """Continuously monitor Jenkins jobs and call callback for failures"""
        logger.info("Starting Jenkins job monitoring...")
        
        while True:
            try:
                failed_jobs = self.get_failed_jobs()
                
                for job in failed_jobs:
                    build_details = self.get_build_details(job.name, job.build_number)
                    if build_details:
                        await callback(build_details)
                
                await asyncio.sleep(self.poll_interval)
                
            except Exception as e:
                logger.error(f"Error in job monitoring: {e}")
                await asyncio.sleep(self.poll_interval)


class JenkinsWebhookHandler:
    """Handle Jenkins webhooks for real-time notifications"""
    
    def __init__(self, secret: str):
        self.secret = secret
        self.callbacks = []
    
    def register_callback(self, callback):
        """Register a callback function for webhook events"""
        self.callbacks.append(callback)
    
    async def handle_webhook(self, payload: Dict[str, Any], signature: str) -> bool:
        """Handle incoming Jenkins webhook"""
        try:
            # Verify signature (implement based on your webhook setup)
            if not self._verify_signature(payload, signature):
                logger.warning("Invalid webhook signature")
                return False
            
            # Process the webhook payload
            event_type = payload.get('name', 'unknown')
            build_data = payload.get('build', {})
            
            if build_data.get('phase') == 'FINISHED':
                status = build_data.get('status', 'UNKNOWN')
                if status in ['FAILURE', 'ABORTED', 'UNSTABLE']:
                    logger.info(f"Webhook received for failed build: {event_type}")
                    
                    # Trigger callbacks
                    for callback in self.callbacks:
                        await callback(payload)
            
            return True
            
        except Exception as e:
            logger.error(f"Error handling webhook: {e}")
            return False
    
    def _verify_signature(self, payload: Dict[str, Any], signature: str) -> bool:
        """Verify webhook signature"""
        # Implement signature verification based on your webhook setup
        # This is a placeholder - implement proper HMAC verification
        return True