# 🤖 AI DevOps Engineer - Jenkins Self-Healing Framework

An intelligent AI agent that performs complete Jenkins failure analysis, contextual reasoning, self-healing, and automated PR creation for unresolved issues.

## 🎯 Overview

This framework autonomously detects, analyzes, and resolves pipeline failures by integrating Jenkins, GitLab, and advanced AI reasoning capabilities. The system learns from past failures to continuously improve its resolution accuracy.

## 🏗️ Architecture

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Jenkins CI/CD │◄──►│  AI Agent Core   │◄──►│   GitLab Repo   │
│                 │    │                  │    │                 │
│ • Build Logs    │    │ • LangChain      │    │ • PR Creation   │
│ • Job Status    │    │ • Groq API       │    │ • Code Review   │
│ • Configs       │    │ • LlamaIndex     │    │ • Merge Status  │
└─────────────────┘    └──────────────────┘    └─────────────────┘
                              │
                              ▼
                       ┌──────────────────┐
                       │  Vector DB       │
                       │                  │
                       │ • FAISS/Chroma   │
                       │ • Pattern Store  │
                       │ • Knowledge Base │
                       └──────────────────┘
```

## 🚀 Core Features

- **🔍 Intelligent Failure Detection**: Real-time monitoring and analysis of Jenkins pipeline failures
- **🧠 Contextual AI Reasoning**: Advanced pattern recognition using RAG and LLM reasoning
- **🔧 Automated Self-Healing**: Auto-fix common issues (syntax, config, environment)
- **📋 Smart PR Creation**: Generate contextual pull requests for complex issues
- **📚 Continuous Learning**: Learn from resolved issues to improve future accuracy
- **🛡️ Security & Compliance**: Built-in SAST/DAST scanning for safety
- **📊 Monitoring Dashboard**: Real-time visualization via Streamlit

## ⚙️ Tech Stack

- **AI/ML**: LangChain, Groq API, LlamaIndex, OpenAI/Claude
- **CI/CD**: Jenkins REST API, GitLab API
- **Database**: Vector DB (FAISS/Chroma/Pinecone)
- **Frontend**: Streamlit, FastAPI
- **Security**: SAST/DAST integration

## 📦 Installation

```bash
# Clone the repository
git clone <repository-url>
cd ai-devops-jenkins-framework

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env with your API keys and configurations

# Initialize vector database
python scripts/init_vector_db.py

# Start the monitoring service
python main.py
```

## 🔧 Configuration

Create a `config.yaml` file to configure Jenkins, GitLab, and AI settings:

```yaml
jenkins:
  url: "https://your-jenkins.com"
  username: "your-username"
  api_token: "your-api-token"
  
gitlab:
  url: "https://gitlab.com"
  token: "your-gitlab-token"
  
ai:
  groq_api_key: "your-groq-key"
  model: "llama3-70b-8192"
  
vector_db:
  type: "faiss"  # or chroma, pinecone
  path: "./data/vector_db"
```

## 🎯 Usage

### Start Monitoring Service
```bash
python main.py --mode monitor
```

### Analyze Specific Job
```bash
python main.py --mode analyze --job "my-pipeline-job" --build 123
```

### Launch Dashboard
```bash
streamlit run dashboard/app.py
```

## 📊 Dashboard Features

- Real-time Jenkins job monitoring
- AI resolution confidence metrics
- Active PRs and their status
- Learning progress visualization
- Failure pattern analysis

## 🔒 Security Features

- Sandboxed code execution
- Automated SAST/DAST scanning
- Approval workflows for critical changes
- Audit logging for all AI actions

## 📈 Learning & Improvement

The system continuously improves by:
- Analyzing successful vs failed resolutions
- Updating vector embeddings with new patterns
- Learning from developer feedback on PRs
- Tracking confidence metrics over time

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Implement your changes
4. Add tests and documentation
5. Submit a pull request

## 📄 License

MIT License - see LICENSE file for details

## 🆘 Support

For issues and questions:
- Create an issue in the repository
- Check the documentation in `/docs`
- Review the configuration examples in `/examples`