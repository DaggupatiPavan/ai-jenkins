#!/usr/bin/env python3
"""
AI DevOps Jenkins Framework - Main Entry Point
Intelligent Jenkins failure analysis, self-healing, and automated PR creation
"""

import asyncio
import argparse
import signal
import sys
from pathlib import Path
from typing import Optional
from loguru import logger
import typer

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from src.utils.config_loader import ConfigLoader
from src.core.decision_engine import DecisionEngine
from src.integrations.jenkins_client import JenkinsClient, JenkinsBuild
from src.integrations.gitlab_client import GitLabClient


class AIDevOpsFramework:
    def __init__(self, config_path: str = "config.yaml"):
        """Initialize the AI DevOps Framework"""
        
        # Load configuration
        self.config = ConfigLoader(config_path)
        self.config.create_directories()
        
        # Setup logging
        self._setup_logging()
        
        # Initialize components
        self.decision_engine = DecisionEngine(self.config.config)
        self.jenkins_client = JenkinsClient(self.config.config)
        self.gitlab_client = GitLabClient(self.config.config)
        
        # State management
        self.running = False
        self.monitoring_task = None
        
        logger.info("AI DevOps Framework initialized")
    
    def _setup_logging(self):
        """Setup logging configuration"""
        log_level = self.config.get('monitoring.log_level', 'INFO')
        log_path = self.config.get('paths.logs', './logs')
        
        # Remove default handler
        logger.remove()
        
        # Add console handler
        logger.add(
            sys.stdout,
            level=log_level,
            format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>"
        )
        
        # Add file handler
        log_file = Path(log_path) / "ai_devops.log"
        logger.add(
            log_file,
            level=log_level,
            format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} - {message}",
            rotation="10 MB",
            retention="30 days"
        )
    
    async def start_monitoring(self):
        """Start continuous Jenkins monitoring"""
        
        if not self.jenkins_client.test_connection():
            logger.error("Failed to connect to Jenkins. Please check your configuration.")
            return False
        
        if not self.gitlab_client.test_connection():
            logger.warning("Failed to connect to GitLab. PR creation will not be available.")
        
        logger.info("Starting Jenkins failure monitoring...")
        self.running = True
        
        # Setup signal handlers
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
        
        try:
            # Start monitoring loop
            await self._monitoring_loop()
        except Exception as e:
            logger.error(f"Monitoring error: {e}")
        finally:
            self.running = False
            logger.info("Monitoring stopped")
    
    async def _monitoring_loop(self):
        """Main monitoring loop"""
        poll_interval = self.config.get('jenkins.poll_interval', 30)
        
        while self.running:
            try:
                logger.debug("Checking for failed Jenkins jobs...")
                
                # Get failed jobs
                failed_jobs = self.jenkins_client.get_failed_jobs(since_hours=1)
                
                if failed_jobs:
                    logger.info(f"Found {len(failed_jobs)} failed jobs to process")
                    
                    for job in failed_jobs:
                        if not self.running:
                            break
                        
                        # Get detailed build information
                        build_details = self.jenkins_client.get_build_details(
                            job.name, job.build_number
                        )
                        
                        if build_details:
                            # Process the failure
                            await self._process_failure(build_details)
                
                # Wait for next poll
                await asyncio.sleep(poll_interval)
                
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                await asyncio.sleep(poll_interval)
    
    async def _process_failure(self, build_details: JenkinsBuild):
        """Process a single Jenkins build failure"""
        
        try:
            logger.info(f"Processing failure: {build_details.job_name}#{build_details.build_number}")
            
            # Get project ID from build metadata or configuration
            project_id = self._extract_project_id(build_details)
            
            # Process through decision engine
            result = await self.decision_engine.process_failure(build_details, project_id)
            
            # Log result
            if result.success:
                logger.info(f"Successfully processed failure: {result.action_taken.value}")
                if result.pr_url:
                    logger.info(f"PR created: {result.pr_url}")
                if result.build_retriggered:
                    logger.info("Build retriggered successfully")
            else:
                logger.error(f"Failed to process failure: {result.error_message}")
            
        except Exception as e:
            logger.error(f"Error processing failure: {e}")
    
    def _extract_project_id(self, build_details: JenkinsBuild) -> Optional[str]:
        """Extract GitLab project ID from build details"""
        
        # Try to get project ID from environment variables
        project_id = build_details.environment_vars.get('GITLAB_PROJECT_ID')
        if project_id:
            return project_id
        
        # Try to extract from git URL or job name
        if build_details.git_branch:
            # This is a simplified approach - in practice, you'd need more sophisticated mapping
            job_name_parts = build_details.job_name.split('/')
            if len(job_name_parts) >= 2:
                return f"{job_name_parts[-2]}/{job_name_parts[-1]}"
        
        # Return default or None
        return self.config.get('gitlab.default_project_id')
    
    async def analyze_specific_job(self, job_name: str, build_number: int):
        """Analyze a specific Jenkins job and build"""
        
        try:
            logger.info(f"Analyzing specific job: {job_name}#{build_number}")
            
            # Get build details
            build_details = self.jenkins_client.get_build_details(job_name, build_number)
            if not build_details:
                logger.error(f"Build details not found for {job_name}#{build_number}")
                return False
            
            # Get project ID
            project_id = self._extract_project_id(build_details)
            
            # Process the failure
            result = await self.decision_engine.process_failure(build_details, project_id)
            
            # Print results
            self._print_analysis_results(build_details, result)
            
            return result.success
            
        except Exception as e:
            logger.error(f"Error analyzing job: {e}")
            return False
    
    def _print_analysis_results(self, build_details: JenkinsBuild, result):
        """Print analysis results to console"""
        
        print("\n" + "="*80)
        print(f"🔍 JENKINS FAILURE ANALYSIS")
        print("="*80)
        print(f"Job: {build_details.job_name}")
        print(f"Build: #{build_details.build_number}")
        print(f"Status: {build_details.status}")
        print(f"Timestamp: {build_details.timestamp}")
        print(f"Duration: {build_details.duration / 1000:.2f}s")
        
        if build_details.git_commit:
            print(f"Git Commit: {build_details.git_commit}")
        
        print(f"\n🤖 AI Action Taken: {result.action_taken.value.upper()}")
        print(f"✅ Success: {result.success}")
        print(f"⏱️  Execution Time: {result.execution_time:.2f}s")
        
        if result.pr_url:
            print(f"🔗 PR Created: {result.pr_url}")
        
        if result.build_retriggered:
            print(f"🔄 Build Retriggered: Yes")
        
        if result.error_message:
            print(f"❌ Error: {result.error_message}")
        
        print("="*80)
    
    async def test_connections(self):
        """Test connections to all services"""
        
        print("🔍 Testing service connections...\n")
        
        # Test Jenkins
        print("Testing Jenkins connection...")
        jenkins_ok = self.jenkins_client.test_connection()
        print(f"Jenkins: {'✅ Connected' if jenkins_ok else '❌ Failed'}")
        
        # Test GitLab
        print("Testing GitLab connection...")
        gitlab_ok = self.gitlab_client.test_connection()
        print(f"GitLab: {'✅ Connected' if gitlab_ok else '❌ Failed'}")
        
        # Test AI components
        print("Testing AI components...")
        try:
            # Simple test of AI engine
            from src.ai.ai_engine import FailureAnalysis
            test_analysis = FailureAnalysis(
                job_name="test",
                build_number=1,
                failure_type="test",
                root_cause="test",
                confidence=0.5,
                severity="low",
                affected_components=[],
                suggested_fixes=[],
                reasoning_trace="test",
                error_patterns=[],
                requires_human_intervention=False
            )
            print("AI Engine: ✅ Initialized")
        except Exception as e:
            print(f"AI Engine: ❌ Failed - {e}")
        
        # Test RAG system
        print("Testing RAG system...")
        try:
            stats = self.decision_engine.rag_system.get_statistics()
            print(f"RAG System: ✅ {stats['total_patterns']} patterns loaded")
        except Exception as e:
            print(f"RAG System: ❌ Failed - {e}")
        
        print(f"\n📊 Overall Status: {'✅ All systems ready' if jenkins_ok else '⚠️  Some issues detected'}")
    
    def _signal_handler(self, signum, frame):
        """Handle shutdown signals"""
        logger.info(f"Received signal {signum}, shutting down...")
        self.running = False
    
    def get_statistics(self):
        """Get framework statistics"""
        
        stats = self.decision_engine.get_statistics()
        rag_stats = stats.get('rag_statistics', {})
        
        print("\n📊 FRAMEWORK STATISTICS")
        print("="*50)
        print(f"Total Actions: {stats.get('total_actions', 0)}")
        print(f"Success Rate: {stats.get('success_rate', 0):.1%}")
        print(f"Action Distribution: {stats.get('action_distribution', {})}")
        print(f"Failure Patterns: {rag_stats.get('total_patterns', 0)}")
        print(f"Resolution History: {rag_stats.get('total_resolutions', 0)}")
        print(f"Overall Success Rate: {rag_stats.get('overall_success_rate', 0):.1%}")
        print("="*50)


# CLI Application
app = typer.Typer(help="AI DevOps Jenkins Framework")


@app.command()
def monitor(
    config_path: str = typer.Option("config.yaml", "--config", "-c", help="Configuration file path")
):
    """Start continuous Jenkins monitoring"""
    
    framework = AIDevOpsFramework(config_path)
    
    try:
        asyncio.run(framework.start_monitoring())
    except KeyboardInterrupt:
        logger.info("Monitoring stopped by user")
    except Exception as e:
        logger.error(f"Monitoring failed: {e}")
        sys.exit(1)


@app.command()
def analyze(
    job_name: str = typer.Argument(..., help="Jenkins job name"),
    build_number: int = typer.Argument(..., help="Build number"),
    config_path: str = typer.Option("config.yaml", "--config", "-c", help="Configuration file path")
):
    """Analyze a specific Jenkins job failure"""
    
    framework = AIDevOpsFramework(config_path)
    
    try:
        success = asyncio.run(framework.analyze_specific_job(job_name, build_number))
        sys.exit(0 if success else 1)
    except Exception as e:
        logger.error(f"Analysis failed: {e}")
        sys.exit(1)


@app.command()
def test(
    config_path: str = typer.Option("config.yaml", "--config", "-c", help="Configuration file path")
):
    """Test connections to all services"""
    
    framework = AIDevOpsFramework(config_path)
    
    try:
        asyncio.run(framework.test_connections())
    except Exception as e:
        logger.error(f"Test failed: {e}")
        sys.exit(1)


@app.command()
def stats(
    config_path: str = typer.Option("config.yaml", "--config", "-c", help="Configuration file path")
):
    """Show framework statistics"""
    
    framework = AIDevOpsFramework(config_path)
    framework.get_statistics()


@app.command()
def dashboard(
    config_path: str = typer.Option("config.yaml", "--config", "-c", help="Configuration file path")
):
    """Launch the monitoring dashboard"""
    
    try:
        import subprocess
        import sys
        
        # Run Streamlit dashboard
        dashboard_path = Path(__file__).parent / "dashboard" / "app.py"
        if not dashboard_path.exists():
            logger.error("Dashboard not found. Please ensure dashboard/app.py exists.")
            sys.exit(1)
        
        cmd = [sys.executable, "-m", "streamlit", "run", str(dashboard_path)]
        subprocess.run(cmd)
        
    except Exception as e:
        logger.error(f"Failed to launch dashboard: {e}")
        sys.exit(1)


if __name__ == "__main__":
    app()