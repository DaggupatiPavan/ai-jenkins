# 📚 AI DevOps Framework User Guide

## Table of Contents

1. [Quick Start](#quick-start)
2. [Installation](#installation)
3. [Configuration](#configuration)
4. [Basic Usage](#basic-usage)
5. [Dashboard Guide](#dashboard-guide)
6. [Advanced Features](#advanced-features)
7. [Troubleshooting](#troubleshooting)
8. [Best Practices](#best-practices)

## Quick Start

### Prerequisites

- Python 3.8 or higher
- Jenkins server with API access
- GitLab account with API token
- Groq API key (for AI processing)

### 5-Minute Setup

1. **Clone and Install**
   ```bash
   git clone <repository-url>
   cd ai-devops-jenkins-framework
   pip install -r requirements.txt
   ```

2. **Configure Environment**
   ```bash
   cp .env.example .env
   # Edit .env with your API keys
   ```

3. **Initialize Vector Database**
   ```bash
   python scripts/init_vector_db.py
   ```

4. **Test Connections**
   ```bash
   python main.py test
   ```

5. **Start Monitoring**
   ```bash
   python main.py monitor
   ```

## Installation

### System Requirements

- **OS**: Linux, macOS, or Windows
- **Python**: 3.8+ (recommended 3.9+)
- **Memory**: Minimum 4GB RAM (8GB+ recommended)
- **Storage**: 10GB free space for vector database and logs
- **Network**: Internet access for AI APIs

### Step-by-Step Installation

#### 1. Clone Repository

```bash
git clone https://github.com/your-org/ai-devops-jenkins-framework.git
cd ai-devops-jenkins-framework
```

#### 2. Create Virtual Environment

```bash
# Using venv
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Using conda
conda create -n ai-devops python=3.9
conda activate ai-devops
```

#### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

#### 4. Configure Environment

```bash
# Copy environment template
cp .env.example .env

# Edit with your configuration
nano .env  # or use your preferred editor
```

#### 5. Initialize System

```bash
# Create necessary directories
mkdir -p data/{vector_db,logs,backups} logs temp

# Initialize vector database with sample patterns
python scripts/init_vector_db.py
```

#### 6. Verify Installation

```bash
# Test all connections
python main.py test

# Should see:
# ✅ All systems ready
```

## Configuration

### Environment Variables (.env)

```bash
# Jenkins Configuration
JENKINS_URL=https://your-jenkins.com
JENKINS_USERNAME=your-username
JENKINS_API_TOKEN=your-api-token
JENKINS_WEBHOOK_SECRET=your-webhook-secret

# GitLab Configuration
GITLAB_TOKEN=your-gitlab-token

# AI Configuration
GROQ_API_KEY=your-groq-api-key

# Optional: Notifications
SLACK_WEBHOOK_URL=your-slack-webhook
SMTP_SERVER=smtp.example.com
```

### Main Configuration (config.yaml)

```yaml
jenkins:
  url: "https://your-jenkins.com"
  username: "${JENKINS_USERNAME}"
  api_token: "${JENKINS_API_TOKEN}"
  poll_interval: 30  # Check every 30 seconds
  max_retries: 3
  timeout: 300

gitlab:
  url: "https://gitlab.com"
  token: "${GITLAB_TOKEN}"
  default_branch: "main"
  require_approval: true

ai:
  groq_api_key: "${GROQ_API_KEY}"
  model: "llama3-70b-8192"
  temperature: 0.1
  confidence_threshold:
    auto_fix: 0.8      # 80% confidence for auto-fix
    pr_creation: 0.6   # 60% confidence for PR
    human_intervention: 0.4  # Below 40% requires human

security:
  enable_sast: true
  sandbox_execution: true
  max_code_changes: 1000
  forbidden_patterns:
    - "rm -rf"
    - "sudo"
    - "chmod 777"
```

### Jenkins Setup

#### 1. Generate API Token

1. Log into Jenkins
2. Go to `Configure` → `API Token`
3. Generate new token
4. Copy token to `.env` file

#### 2. Configure Webhooks (Optional)

For real-time failure detection:

```bash
# In Jenkins job configuration:
# Post-build Actions → Trigger parameterized build on other projects
# URL: http://your-framework-server:8000/webhook/jenkins
# Secret: Use the same value as JENKINS_WEBHOOK_SECRET
```

#### 3. Job Naming Convention

Use consistent job naming for better pattern recognition:
- `project/build-pipeline`
- `project/test-suite`
- `project/deploy-staging`

### GitLab Setup

#### 1. Generate Personal Access Token

1. Go to GitLab → User Settings → Access Tokens
2. Create token with `api`, `repository`, `write_repository` scopes
3. Copy token to `.env` file

#### 2. Project Configuration

The framework needs to know which GitLab project to create PRs in:

```yaml
# In config.yaml or environment
gitlab:
  default_project_id: "group/project-name"
```

Or set in job environment variables:
```bash
GITLAB_PROJECT_ID=group/project-name
```

## Basic Usage

### Command Line Interface

#### Start Monitoring

```bash
# Start continuous monitoring
python main.py monitor

# With custom config
python main.py monitor --config custom-config.yaml
```

#### Analyze Specific Job

```bash
# Analyze a specific failure
python main.py analyze "my-pipeline-job" 123

# The framework will:
# 1. Fetch build details
# 2. Analyze failure with AI
# 3. Generate fix proposal
# 4. Create PR or apply auto-fix
```

#### View Statistics

```bash
# Show framework statistics
python main.py stats

# Output includes:
# - Total actions taken
# - Success rates
# - Pattern distribution
# - Learning progress
```

#### Launch Dashboard

```bash
# Start web dashboard
python main.py dashboard

# Access at http://localhost:8501
```

### Web Interface

#### Dashboard Overview

The Streamlit dashboard provides:

- **Real-time Monitoring**: Live Jenkins job status
- **AI Analytics**: Success rates and pattern analysis
- **Active PRs**: Track AI-generated pull requests
- **Manual Analysis**: Analyze specific jobs on-demand

#### Key Dashboard Features

1. **Overview Tab**
   - System metrics and health
   - Action distribution charts
   - Recent activity feed

2. **Activity Tab**
   - Recent failed jobs
   - AI actions taken
   - Success/failure tracking

3. **Patterns Tab**
   - Failure type distribution
   - Learning progress over time
   - Pattern effectiveness

4. **PRs Tab**
   - Active pull requests
   - PR status and approval
   - Merge success rates

5. **Tools Tab**
   - Manual job analysis
   - Data export
   - Configuration testing

## Advanced Features

### Custom Confidence Thresholds

Adjust when the AI takes different actions:

```yaml
ai:
  confidence_threshold:
    auto_fix: 0.9      # Very confident for auto-fixes
    pr_creation: 0.7   # Moderately confident for PRs
    human_intervention: 0.3  # Low confidence escalates to human
```

### Security Configuration

Enhance security settings:

```yaml
security:
  enable_sast: true
  enable_dast: false
  sandbox_execution: true
  max_code_changes: 500  # Reduce for higher security
  forbidden_patterns:
    - "rm -rf"
    - "sudo"
    - "chmod 777"
    - "eval"
    - "exec"
```

### Custom Patterns

Add your own failure patterns:

```python
from src.ai.rag_system import FailurePattern

pattern = FailurePattern(
    id="",
    job_name="my-custom-job",
    failure_type="custom_error",
    error_signature="Specific error message",
    root_cause="Known root cause",
    solution_applied="Proven solution",
    success_rate=0.95,
    occurrence_count=1,
    last_seen=datetime.now()
)

# Add to RAG system
rag_system.add_failure_pattern(pattern)
```

### Notification Integration

Configure Slack notifications:

```yaml
monitoring:
  alert_channels:
    slack:
      webhook_url: "${SLACK_WEBHOOK_URL}"
      enabled: true
```

Example Slack notification:
```
🚨 Jenkins Failure Requires Human Intervention

Job: build-pipeline
Build: #123
Failure Type: configuration_error
Severity: medium
Root Cause: Missing environment variable
```

### Multi-Project Setup

For multiple GitLab projects:

```yaml
# Method 1: Environment variables per job
# In Jenkins job configuration:
GITLAB_PROJECT_ID=group/project-a

# Method 2: Mapping in config
gitlab_project_mapping:
  "project-a/*": "group/project-a"
  "project-b/*": "group/project-b"
```

## Troubleshooting

### Common Issues

#### 1. Jenkins Connection Failed

**Error**: `Failed to connect to Jenkins`

**Solutions**:
- Verify Jenkins URL is accessible
- Check API token permissions
- Ensure username is correct
- Test with curl: `curl -u username:token http://jenkins:8080/api/json`

#### 2. GitLab API Errors

**Error**: `Failed to connect to GitLab`

**Solutions**:
- Verify GitLab URL and token
- Check token has required scopes
- Test with GitLab CLI: `gitlab project list`

#### 3. AI API Errors

**Error**: `Groq API authentication failed`

**Solutions**:
- Verify Groq API key is valid
- Check API quota and limits
- Ensure model name is correct

#### 4. Vector Database Issues

**Error**: `Failed to initialize vector database`

**Solutions**:
- Check disk space and permissions
- Reinitialize: `python scripts/init_vector_db.py`
- Verify embedding model is downloaded

#### 5. Permission Errors

**Error**: `Permission denied` when creating files

**Solutions**:
- Check directory permissions
- Run with appropriate user
- Create directories manually: `mkdir -p data logs`

### Debug Mode

Enable debug logging:

```yaml
monitoring:
  log_level: "DEBUG"
```

Or via environment:
```bash
export LOG_LEVEL=DEBUG
python main.py monitor
```

### Health Checks

Run comprehensive health check:

```bash
python main.py test
```

This tests:
- Jenkins connectivity
- GitLab connectivity
- AI engine initialization
- Vector database status
- Configuration validation

### Log Analysis

Check logs for issues:

```bash
# View recent logs
tail -f logs/ai_devops.log

# Search for errors
grep "ERROR" logs/ai_devops.log

# Monitor specific component
grep "DecisionEngine" logs/ai_devops.log
```

## Best Practices

### 1. Security

- **Regular API Key Rotation**: Update API keys monthly
- **Principle of Least Privilege**: Minimal required permissions
- **Audit Trail**: Review action logs regularly
- **Sandbox Testing**: Always test in non-production first

### 2. Configuration

- **Environment-Specific Configs**: Separate configs for dev/staging/prod
- **Secret Management**: Use proper secret management tools
- **Backup Configuration**: Version control your config files
- **Regular Updates**: Keep dependencies updated

### 3. Monitoring

- **Set Up Alerts**: Configure notifications for critical failures
- **Review Dashboard**: Check dashboard daily for anomalies
- **Performance Metrics**: Monitor AI accuracy and success rates
- **Capacity Planning**: Monitor resource usage

### 4. AI Training

- **Start Conservative**: Use high confidence thresholds initially
- **Gradual Learning**: Lower thresholds as system learns
- **Human Feedback**: Regularly review and provide feedback
- **Pattern Review**: Periodically review learned patterns

### 5. Integration

- **Test Environment**: Always test in development first
- **Rollback Plan**: Have plan to disable AI automation
- **Documentation**: Document custom configurations
- **Team Training**: Train team on AI capabilities and limitations

### Performance Optimization

#### 1. Resource Management

```yaml
# Optimize for your environment
jenkins:
  poll_interval: 60  # Reduce frequency for large installations

ai:
  max_tokens: 2048  # Reduce for faster responses
  temperature: 0.0  # More deterministic responses
```

#### 2. Database Optimization

```yaml
vector_db:
  type: "faiss"  # Faster for large datasets
  dimension: 384  # Balance between accuracy and speed
```

#### 3. Caching

Enable caching for frequently accessed data:

```python
# In custom code
from functools import lru_cache

@lru_cache(maxsize=128)
def get_job_config(job_name):
    return jenkins_client.get_job_config(job_name)
```

### Scaling Considerations

#### 1. Horizontal Scaling

- **Multiple Instances**: Run multiple framework instances
- **Load Balancing**: Distribute Jenkins monitoring
- **Queue Management**: Use message queues for job distribution

#### 2. Database Scaling

- **Vector Database**: Consider Pinecone for large-scale deployments
- **Partitioning**: Partition patterns by project or time
- **Archiving**: Archive old patterns periodically

#### 3. Monitoring Scaling

- **Metrics Collection**: Use Prometheus/Grafana
- **Distributed Tracing**: Track requests across components
- **Alert Management**: Integrate with PagerDuty/Opsgenie

This user guide provides comprehensive information for effectively using the AI DevOps Framework. Start with the basic setup and gradually explore advanced features as you become more familiar with the system.