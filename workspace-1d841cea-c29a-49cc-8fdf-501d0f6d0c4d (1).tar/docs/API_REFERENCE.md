# 📖 API Reference

## Overview

The AI DevOps Framework provides both programmatic APIs and REST endpoints for integration with external systems. This document covers all available APIs, their parameters, and usage examples.

## Table of Contents

1. [Python API](#python-api)
2. [REST API](#rest-api)
3. [Webhook API](#webhook-api)
4. [Configuration API](#configuration-api)
5. [Data Models](#data-models)
6. [Error Handling](#error-handling)

## Python API

### Core Classes

#### DecisionEngine

Main orchestrator for failure analysis and resolution.

```python
from src.core.decision_engine import DecisionEngine
from src.utils.config_loader import ConfigLoader

# Initialize
config = ConfigLoader("config.yaml")
engine = DecisionEngine(config.config)

# Process failure
result = await engine.process_failure(jenkins_build, project_id)
```

**Methods**

##### `process_failure(jenkins_build: JenkinsBuild, project_id: str = None) -> ActionResult`

Process a Jenkins build failure and determine appropriate action.

**Parameters:**
- `jenkins_build`: Jenkins build object with failure details
- `project_id`: GitLab project ID for PR creation (optional)

**Returns:** `ActionResult` object with execution results

**Example:**
```python
from src.integrations.jenkins_client import JenkinsClient

jenkins = JenkinsClient(config)
build = jenkins.get_build_details("my-job", 123)
result = await engine.process_failure(build, "group/project")
```

##### `get_statistics() -> Dict[str, Any]`

Get framework statistics and performance metrics.

**Returns:** Dictionary with statistics including:
- `total_actions`: Number of actions taken
- `success_rate`: Overall success rate
- `action_distribution`: Breakdown by action type
- `rag_statistics`: Pattern learning statistics

#### AIEngine

Core AI reasoning and analysis engine.

```python
from src.ai.ai_engine import AIEngine

ai = AIEngine(config.config)

# Analyze failure
analysis = await ai.analyze_failure(jenkins_build)

# Generate fix
fix = await ai.generate_fix(analysis, jenkins_build)

# Assess feasibility
assessment = await ai.assess_auto_fix_feasibility(analysis, fix)
```

**Methods**

##### `analyze_failure(jenkins_build: JenkinsBuild) -> FailureAnalysis`

Analyze a Jenkins build failure using AI.

**Parameters:**
- `jenkins_build`: Jenkins build object

**Returns:** `FailureAnalysis` object with detailed analysis

##### `generate_fix(analysis: FailureAnalysis, jenkins_build: JenkinsBuild, code_context: Dict = None) -> FixProposal`

Generate a comprehensive fix proposal.

**Parameters:**
- `analysis`: Failure analysis result
- `jenkins_build`: Original build details
- `code_context`: Additional context for fix generation (optional)

**Returns:** `FixProposal` object with suggested solution

#### RAGSystem

Retrieval-Augmented Generation system for pattern learning.

```python
from src.ai.rag_system import RAGSystem

rag = RAGSystem(config.config)

# Search similar patterns
patterns = rag.search_similar_patterns("compilation error", top_k=5)

# Get resolution suggestions
suggestions = rag.get_resolution_suggestions(failure_analysis)

# Record outcome
rag.record_resolution(pattern_id, resolution)
```

**Methods**

##### `search_similar_patterns(query_text: str, top_k: int = 5) -> List[Tuple[FailurePattern, float]]`

Search for similar failure patterns.

**Parameters:**
- `query_text`: Query text for similarity search
- `top_k`: Number of results to return

**Returns:** List of tuples with pattern and similarity score

##### `add_failure_pattern(pattern: FailurePattern) -> bool`

Add a new failure pattern to the knowledge base.

**Parameters:**
- `pattern`: FailurePattern object to add

**Returns:** True if successfully added

##### `get_resolution_suggestions(failure_analysis: Dict[str, Any]) -> List[Dict[str, Any]]`

Get resolution suggestions based on similar patterns.

**Parameters:**
- `failure_analysis`: Failure analysis data

**Returns:** List of resolution suggestions with historical context

#### JenkinsClient

Jenkins API integration client.

```python
from src.integrations.jenkins_client import JenkinsClient

jenkins = JenkinsClient(config.config)

# Get failed jobs
failed_jobs = jenkins.get_failed_jobs(since_hours=24)

# Get build details
build = jenkins.get_build_details("job-name", 123)

# Trigger build
jenkins.trigger_build("job-name", {"param": "value"})
```

**Methods**

##### `get_failed_jobs(since_hours: int = 24) -> List[JenkinsJob]`

Get jobs that have failed in the specified time window.

**Parameters:**
- `since_hours`: Hours to look back for failures

**Returns:** List of `JenkinsJob` objects

##### `get_build_details(job_name: str, build_number: int) -> Optional[JenkinsBuild]`

Get detailed information about a specific build.

**Parameters:**
- `job_name`: Name of the Jenkins job
- `build_number`: Build number

**Returns:** `JenkinsBuild` object or None if not found

##### `trigger_build(job_name: str, parameters: Dict[str, Any] = None) -> bool`

Trigger a new build for a job.

**Parameters:**
- `job_name`: Name of the job to build
- `parameters`: Build parameters (optional)

**Returns:** True if successfully triggered

#### GitLabClient

GitLab API integration client.

```python
from src.integrations.gitlab_client import GitLabClient

gitlab = GitLabClient(config.config)

# Create fix PR
pr = gitlab.create_fix_pr(project_id, issue_analysis, proposed_fix)

# Update file
gitlab.update_file(project_id, "path/to/file", content, "branch", "message")

# Get PR status
status = gitlab.get_pr_status(project_id, pr.iid)
```

**Methods**

##### `create_fix_pr(project_id: str, issue_analysis: Dict, proposed_fix: Dict) -> Optional[GitLabPR]`

Create a comprehensive fix pull request.

**Parameters:**
- `project_id`: GitLab project ID
- `issue_analysis`: Failure analysis data
- `proposed_fix`: Fix proposal data

**Returns:** `GitLabPR` object or None if failed

##### `update_file(project_id: str, file_path: str, content: str, branch: str, commit_message: str) -> bool`

Update a file in the repository.

**Parameters:**
- `project_id`: GitLab project ID
- `file_path`: Path to file
- `content`: New file content
- `branch`: Branch name
- `commit_message`: Commit message

**Returns:** True if successfully updated

## REST API

### Base URL

```
http://localhost:8000/api/v1
```

### Authentication

Include API key in header:
```
Authorization: Bearer your-api-key
```

### Endpoints

#### GET /health

Health check endpoint.

**Response:**
```json
{
  "status": "healthy",
  "timestamp": "2024-01-01T12:00:00Z",
  "version": "1.0.0",
  "components": {
    "jenkins": "connected",
    "gitlab": "connected",
    "ai_engine": "ready",
    "rag_system": "ready"
  }
}
```

#### POST /analyze

Analyze a Jenkins failure.

**Request Body:**
```json
{
  "job_name": "my-pipeline",
  "build_number": 123,
  "project_id": "group/project"
}
```

**Response:**
```json
{
  "success": true,
  "action_taken": "create_pr",
  "confidence": 0.85,
  "execution_time": 2.3,
  "pr_url": "https://gitlab.com/group/project/-/merge_requests/45",
  "analysis": {
    "failure_type": "configuration_error",
    "root_cause": "Missing environment variable",
    "severity": "medium"
  }
}
```

#### GET /statistics

Get framework statistics.

**Response:**
```json
{
  "total_actions": 150,
  "success_rate": 0.87,
  "action_distribution": {
    "auto_fix": 45,
    "create_pr": 78,
    "human_intervention": 27
  },
  "rag_statistics": {
    "total_patterns": 234,
    "total_resolutions": 150,
    "overall_success_rate": 0.87
  }
}
```

#### GET /jobs/{job_name}/builds/{build_number}

Get details for a specific build.

**Path Parameters:**
- `job_name`: Jenkins job name
- `build_number`: Build number

**Response:**
```json
{
  "job_name": "my-pipeline",
  "build_number": 123,
  "status": "FAILURE",
  "timestamp": "2024-01-01T12:00:00Z",
  "duration": 120000,
  "console_log": "Build log excerpt...",
  "test_results": {
    "total": 100,
    "failed": 5,
    "passed": 95
  }
}
```

#### GET /patterns

Search failure patterns.

**Query Parameters:**
- `query`: Search query
- `limit`: Number of results (default: 10)
- `failure_type`: Filter by failure type

**Response:**
```json
{
  "patterns": [
    {
      "id": "pattern_123",
      "failure_type": "compilation",
      "root_cause": "Missing dependency",
      "success_rate": 0.92,
      "occurrence_count": 8,
      "similarity_score": 0.89
    }
  ],
  "total": 1
}
```

#### POST /patterns

Create a new failure pattern.

**Request Body:**
```json
{
  "job_name": "my-pipeline",
  "failure_type": "compilation",
  "error_signature": "npm install failed",
  "root_cause": "Missing package.json dependency",
  "solution_applied": "Update package.json with missing dependency",
  "metadata": {
    "severity": "medium",
    "affected_components": ["npm", "build"]
  }
}
```

#### GET /pull-requests

List active pull requests.

**Query Parameters:**
- `status`: Filter by status (open, closed, merged)
- `limit`: Number of results (default: 20)

**Response:**
```json
{
  "pull_requests": [
    {
      "id": 45,
      "iid": 45,
      "title": "🤖 AI Auto-Fix: configuration_error",
      "status": "open",
      "author": "ai-devops-bot",
      "created_at": "2024-01-01T12:00:00Z",
      "web_url": "https://gitlab.com/group/project/-/merge_requests/45"
    }
  ]
}
```

## Webhook API

### Jenkins Webhook

Handle Jenkins build notifications.

**Endpoint:** `POST /webhook/jenkins`

**Headers:**
- `X-Jenkins-Event`: Event type
- `X-Hub-Signature`: HMAC signature (if configured)

**Request Body (Jenkins format):**
```json
{
  "name": "my-pipeline",
  "build": {
    "number": 123,
    "phase": "FINISHED",
    "status": "FAILURE",
    "url": "https://jenkins/job/my-pipeline/123/",
    "full_url": "https://jenkins/job/my-pipeline/123/"
  }
}
```

**Response:**
```json
{
  "received": true,
  "job": "my-pipeline",
  "build": 123,
  "status": "processing"
}
```

### GitLab Webhook

Handle GitLab merge request events.

**Endpoint:** `POST /webhook/gitlab`

**Headers:**
- `X-Gitlab-Event`: Event type
- `X-Gitlab-Token`: Verification token

**Request Body (GitLab format):**
```json
{
  "object_kind": "merge_request",
  "object_attributes": {
    "iid": 45,
    "title": "🤖 AI Auto-Fix: configuration_error",
    "state": "opened",
    "action": "open"
  },
  "project": {
    "id": 123,
    "path_with_namespace": "group/project"
  }
}
```

## Configuration API

### Get Configuration

```python
from src.utils.config_loader import ConfigLoader

config = ConfigLoader("config.yaml")

# Get specific sections
jenkins_config = config.get_jenkins_config()
ai_config = config.get_ai_config()
security_config = config.get_security_config()

# Get specific values
poll_interval = config.get('jenkins.poll_interval', 30)
api_key = config.get('ai.groq_api_key')
```

### Update Configuration

```python
# Update values
config.set('jenkins.poll_interval', 60)
config.set('ai.temperature', 0.2)

# Save changes
config.save()
```

### Validate Configuration

```python
try:
    config = ConfigLoader("config.yaml")
    # Configuration is valid
except ValueError as e:
    print(f"Configuration error: {e}")
```

## Data Models

### JenkinsBuild

```python
@dataclass
class JenkinsBuild:
    job_name: str
    build_number: int
    status: str
    timestamp: datetime
    duration: int
    console_log: str
    test_results: Optional[Dict[str, Any]]
    artifacts: List[Dict[str, Any]]
    environment_vars: Dict[str, str]
    git_commit: Optional[str]
    git_branch: Optional[str]
```

### FailureAnalysis

```python
@dataclass
class FailureAnalysis:
    job_name: str
    build_number: int
    failure_type: str
    root_cause: str
    confidence: float
    severity: str
    affected_components: List[str]
    suggested_fixes: List[str]
    reasoning_trace: str
    error_patterns: List[str]
    requires_human_intervention: bool
```

### FixProposal

```python
@dataclass
class FixProposal:
    solution_description: str
    file_changes: List[Dict[str, Any]]
    commands_to_run: List[str]
    configuration_changes: Dict[str, Any]
    confidence: float
    estimated_success_rate: float
    risks: List[str]
    testing_required: bool
```

### ActionResult

```python
@dataclass
class ActionResult:
    success: bool
    action_taken: ActionType
    result_details: Dict[str, Any]
    error_message: Optional[str] = None
    execution_time: float = 0.0
    pr_url: Optional[str] = None
    build_retriggered: bool = False
```

### FailurePattern

```python
@dataclass
class FailurePattern:
    id: str
    job_name: str
    failure_type: str
    error_signature: str
    root_cause: str
    solution_applied: str
    success_rate: float
    occurrence_count: int
    last_seen: datetime
    embedding: Optional[np.ndarray] = None
    metadata: Dict[str, Any] = None
```

## Error Handling

### Exception Types

```python
# Configuration errors
class ConfigurationError(Exception):
    """Raised when configuration is invalid"""
    pass

# Integration errors
class JenkinsConnectionError(Exception):
    """Raised when Jenkins connection fails"""
    pass

class GitLabConnectionError(Exception):
    """Raised when GitLab connection fails"""
    pass

# AI errors
class AIProcessingError(Exception):
    """Raised when AI processing fails"""
    pass

class InsufficientConfidenceError(Exception):
    """Raised when AI confidence is too low"""
    pass

# Security errors
class SecurityViolationError(Exception):
    """Raised when security check fails"""
    pass

# RAG errors
class PatternNotFoundError(Exception):
    """Raised when no similar patterns found"""
    pass
```

### Error Response Format

REST API errors follow this format:

```json
{
  "error": {
    "code": "JENKINS_CONNECTION_ERROR",
    "message": "Failed to connect to Jenkins server",
    "details": {
      "url": "https://jenkins.example.com",
      "status_code": 401,
      "timestamp": "2024-01-01T12:00:00Z"
    }
  }
}
```

### Common Error Codes

| Error Code | Description | HTTP Status |
|------------|-------------|-------------|
| `CONFIGURATION_ERROR` | Invalid configuration | 400 |
| `JENKINS_CONNECTION_ERROR` | Jenkins connection failed | 503 |
| `GITLAB_CONNECTION_ERROR` | GitLab connection failed | 503 |
| `AI_PROCESSING_ERROR` | AI processing failed | 500 |
| `INSUFFICIENT_CONFIDENCE` | AI confidence too low | 422 |
| `SECURITY_VIOLATION` | Security check failed | 403 |
| `PATTERN_NOT_FOUND` | No similar patterns found | 404 |
| `BUILD_NOT_FOUND` | Jenkins build not found | 404 |
| `PROJECT_NOT_FOUND` | GitLab project not found | 404 |

### Error Handling Best Practices

```python
try:
    result = await engine.process_failure(build, project_id)
except JenkinsConnectionError:
    logger.error("Jenkins is unavailable")
    # Implement retry logic or fallback
except AIProcessingError:
    logger.error("AI processing failed")
    # Escalate to human intervention
except SecurityViolationError:
    logger.error("Security violation detected")
    # Block action and notify security team
except Exception as e:
    logger.error(f"Unexpected error: {e}")
    # Generic error handling
```

This API reference provides comprehensive documentation for integrating with the AI DevOps Framework. Use the Python API for programmatic access and the REST API for external system integration.